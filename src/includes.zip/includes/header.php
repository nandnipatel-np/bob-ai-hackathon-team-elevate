<?php 
if(session_status() === PHP_SESSION_NONE) session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22; /* CCP Orange */
            --secondary: #1a1a1a; /* Dark gray/black */
            --white: #ffffff;
            --text-main: #2d3436;
            --shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 5%;
            background: var(--white);
            box-shadow: var(--shadow);
            font-family: 'Plus Jakarta Sans', sans-serif;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar .logo {
            font-size: 24px;
            font-weight: 800;
            color: var(--secondary);
            text-decoration: none;
            /* Removed lowercase transform to match CCP branding */
        }

        .navbar .logo span {
            color: var(--primary);
        }

        .nav-user-info {
            display: flex;
            align-items: center;
            gap: 20px;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-main);
        }

        .nav-user-info a {
            text-decoration: none;
            padding: 8px 18px;
            border-radius: 10px;
            transition: 0.3s;
            font-weight: 700;
        }

        .login-btn {
            background: var(--primary);
            color: white;
        }

        .login-btn:hover {
            background: #d35400;
        }

        .logout-btn {
            color: #ef4444;
            background: #fef2f2;
        }

        .logout-btn:hover {
            background: #fee2e2;
        }
    </style>
</head>
<body>

<div class="navbar">
    <a href="/campus_canteen/customer/dashboard.php" class="logo">CC<span>P</span></a>
    
    <div class="nav-user-info">
        <?php if(isset($_SESSION['user_id'])): ?>
            <span>Welcome, <strong><?= htmlspecialchars($_SESSION['name']) ?></strong></span>
            <a href="/campus_canteen/logout.php" class="logout-btn">Logout</a>
        <?php else: ?>
            <a href="/campus_canteen/login.php" class="login-btn">Login</a>
        <?php endif; ?>
    </div>
</div>