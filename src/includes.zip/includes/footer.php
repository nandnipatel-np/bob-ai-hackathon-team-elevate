<style>
    .main-footer {
        background: #ffffff;
        border-top: 1px solid #f1f5f9;
        padding: 40px 0;
        margin-top: 60px;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    .footer-content {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 24px;
    }

    .footer-logo {
        font-size: 20px;
        font-weight: 800;
        color: #1a1a1a;
        text-decoration: none;
        /* Removed lowercase transform for CCP branding */
    }

    .footer-logo span {
        color: #e67e22; /* CCP Orange */
    }

    .footer-info {
        color: #636e72;
        font-size: 13px;
        font-weight: 600;
    }

    .footer-links {
        display: flex;
        gap: 24px;
    }

    .footer-links a {
        color: #636e72;
        text-decoration: none;
        font-size: 13px;
        font-weight: 700;
        transition: 0.3s;
    }

    .footer-links a:hover {
        color: #e67e22;
    }

    @media (max-width: 768px) {
        .footer-content {
            flex-direction: column;
            gap: 20px;
            text-align: center;
        }
    }
</style>

<footer class="main-footer">
    <div class="footer-content">
        <a href="#" class="footer-logo">CC<span>P</span></a>
        
        <div class="footer-info">
            &copy; 2026 Charusat University. Built for modern campus dining.
        </div>

        <div class="footer-links">
            <a href="/campus_canteen/customer/dashboard.php">Dashboard</a>
            <a href="/campus_canteen/customer/orders.php">My Orders</a>
            <a href="mailto:support@charusat.edu.in">Support</a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>