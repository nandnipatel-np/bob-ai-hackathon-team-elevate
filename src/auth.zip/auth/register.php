<?php
require "config/db.php";
include "includes/header.php";

if (isset($_POST['register'])) {

    $name = htmlspecialchars(trim($_POST['name']));
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $customer_id = trim($_POST['customer_id']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    if ($password != $confirm) {
        echo "<div style='color:red; text-align:center; margin:20px;'>Passwords do not match</div>";
    } else {

        // Check if email already exists
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            echo "<div style='color:red; text-align:center; margin:20px;'>Email already registered</div>";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO users (customer_id, name, email, phone, password, role)
                                    VALUES (?, ?, ?, ?, ?, 'customer')");
            $stmt->bind_param("issss", $customer_id, $name, $email, $phone, $hashed);

            if ($stmt->execute()) {
                echo "<div style='color:green; text-align:center; margin:20px;'>Registration Successful!</div>";
            } else {
                echo "<div style='color:red; text-align:center; margin:20px;'>Registration Failed</div>";
            }
        }
    }
}
?>

<form method="POST" style="max-width:400px; margin:40px auto; display:flex; flex-direction:column; gap:12px;">
    <input name="customer_id" placeholder="Customer ID" required>
    <input name="name" placeholder="Name" required>
    <input name="email" type="email" placeholder="Email" required>
    <input name="phone" placeholder="Phone" required>
    <input name="password" type="password" placeholder="Password" required>
    <input name="confirm" type="password" placeholder="Confirm Password" required>
    <button name="register" style="padding:10px; background:#e67e22; color:white; border:none; border-radius:8px;">Register</button>
</form>