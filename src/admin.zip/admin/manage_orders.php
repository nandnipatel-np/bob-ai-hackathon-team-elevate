<?php
session_start();
require_once '../config/db.php';

// Set Timezone to India
date_default_timezone_set('Asia/Kolkata');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];

// Fetch Admin's Canteen ID
$stmt = $pdo->prepare("SELECT canteen_id FROM users WHERE id = ?");
$stmt->execute([$admin_id]);
$canteen_id = $stmt->fetchColumn();

if (!$canteen_id) {
    die("<div style='padding:50px; text-align:center;'><h2>Account Not Configured</h2><a href='../logout.php'>Logout</a></div>");
}

/* =========================
   ORDER STATUS UPDATE
========================= */
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];

    $allowed_statuses = ['Pending', 'Preparing', 'Ready', 'Completed'];

    if (in_array($new_status, $allowed_statuses)) {
        $stmt_update = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ? AND canteen_id = ?");
        $stmt_update->execute([$new_status, $order_id, $canteen_id]);
    }

    header("Location: manage_orders.php?msg=updated");
    exit();
}

/* =========================
   PAYMENT APPROVE / REJECT
========================= */
if (isset($_POST['update_payment'])) {
    $order_id = $_POST['order_id'];
    $payment_status = $_POST['payment_status'];

    $allowed_payment_status = ['Approved', 'Rejected', 'Pending'];

    if (in_array($payment_status, $allowed_payment_status)) {
        $stmt = $pdo->prepare("UPDATE payments SET payment_status = ? WHERE order_id = ?");
        $stmt->execute([$payment_status, $order_id]);
    }

    header("Location: manage_orders.php?msg=payment_updated");
    exit();
}

// Fetch Canteen Name
$stmt = $pdo->prepare("SELECT name FROM canteens WHERE id = ?");
$stmt->execute([$canteen_id]);
$canteen_name = $stmt->fetchColumn();

// Fetch Orders with Payment Proof
$stmt = $pdo->prepare("
    SELECT o.*, u.name AS customer_name, u.customer_id, 
           p.payment_status, p.payment_proof
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    LEFT JOIN payments p ON o.id = p.order_id
    WHERE o.canteen_id = ?
    ORDER BY o.order_date DESC
");
$stmt->execute([$canteen_id]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root { --primary: #e67e22; --secondary: #1a1a1a; --bg: #f8fafc; --sidebar-width: 280px; }
        * { box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; display: flex; background: var(--bg); margin: 0; }

        .sidebar { width: var(--sidebar-width); background: var(--secondary); color: white; height: 100vh; padding: 40px 24px; position: fixed; left: 0; top: 0; z-index: 100; }
        .logo { font-size: 32px; font-weight: 800; color: #ffffff; margin-bottom: 5px; text-decoration: none; display: block; }
        .logo span { color: var(--primary); }

        .canteen-badge { background: rgba(230, 126, 34, 0.2); color: var(--primary); padding: 5px 12px; border-radius: 8px; font-size: 11px; font-weight: 800; margin: 10px 0 40px 0; display: inline-block; text-transform: uppercase; }
        .sidebar a { display: block; color: #94a3b8; text-decoration: none; padding: 14px 16px; margin-bottom: 8px; border-radius: 12px; font-weight: 600; transition: 0.2s; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.05); color: white; }

        .main { margin-left: var(--sidebar-width); padding: 40px 60px; width: calc(100% - var(--sidebar-width)); }
        .card { background: white; padding: 30px; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); border: 1px solid #f1f5f9; margin-bottom: 30px; overflow-x: auto; }

        table { width: 100%; border-collapse: collapse; min-width: 1200px; }
        th { text-align: left; font-size: 11px; text-transform: uppercase; color: #636e72; padding: 15px; border-bottom: 2px solid #f1f5f9; letter-spacing: 0.5px; }
        td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; vertical-align: middle; }

        .btn-update { background: var(--primary); color: white; border: none; padding: 10px 18px; border-radius: 10px; font-weight: 700; cursor: pointer; transition: 0.3s; text-decoration: none; display: inline-block; }
        .btn-update:hover { background: #d35400; transform: translateY(-1px); }

        .btn-approve { background: green; color: white; border: none; padding: 8px 12px; border-radius: 8px; cursor: pointer; font-weight: 700; }
        .btn-reject { background: red; color: white; border: none; padding: 8px 12px; border-radius: 8px; cursor: pointer; font-weight: 700; }

        select { padding: 8px; border-radius: 8px; border: 1px solid #ddd; font-family: inherit; font-weight: 600; }
        .status-text { font-weight: 800; font-size: 11px; text-transform: uppercase; }
        .payment-badge { font-size: 11px; font-weight: 700; padding: 4px 8px; border-radius: 8px; background: #f1f5f9; color: #334155; display: inline-block; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <div class="canteen-badge"><?= htmlspecialchars($canteen_name) ?></div>
        <nav>
            <a href="manage_orders.php" class="active">Live Orders</a>
            <a href="manage_menu.php">Menu Management</a>
            <a href="reports.php">Sales Reports</a>
            <a href="../logout.php" style="color:#ef4444; margin-top:50px;">Logout</a>
        </nav>
    </div>

    <div class="main">
        <h1 style="margin-top:0; font-weight: 800;">Incoming Orders</h1>
        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Customer ID</th>
                        <th>Order Date</th>
                        <th>Order Time</th>
                        <th>Amount</th>
                        <th>Pickup</th>
                        <th>Payment</th>
                        <th>Proof</th>
                        <th>Payment Action</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($orders) > 0): ?>
                        <?php foreach ($orders as $o): ?>
                        <tr>
                            <td><strong>#<?= htmlspecialchars($o['order_number']) ?></strong></td>
                            <td><?= htmlspecialchars($o['customer_name'] ?? 'Guest') ?></td>
                            <td><?= htmlspecialchars($o['customer_id'] ?? '-') ?></td>

                            <td style="font-weight: 600; color: #636e72;">
                                <?= date('d M, Y', strtotime($o['order_date'])) ?>
                            </td>

                            <td style="font-weight: 700; color: var(--primary);">
                                <?= date('h:i A', strtotime($o['order_date'])) ?>
                            </td>

                            <td><strong style="font-size: 16px;">₹<?= number_format($o['total_amount'], 2) ?></strong></td>

                            <td>
                                <span style="font-size: 12px; background: #f1f5f9; padding: 4px 8px; border-radius: 6px; font-weight: 700;">
                                    <?= date('h:i A', strtotime($o['scheduled_pickup_time'])) ?>
                                </span>
                            </td>

                            <!-- Payment Status -->
                            <td>
                                <span class="payment-badge">
                                    <?= htmlspecialchars($o['payment_status'] ?? 'Pending') ?>
                                </span>
                            </td>

                            <!-- View Proof -->
                            <td>
                                <?php
                                $proofFile = $o['payment_proof'] ?? '';
                                $proofPath = __DIR__ . '/../assets/images/proofs/' . $proofFile;
                                $proofUrl = '../assets/images/proofs/' . urlencode($proofFile);
                                ?>

                                <?php if (!empty($proofFile) && file_exists($proofPath)): ?>
                                    <a href="<?= $proofUrl ?>" target="_blank" class="btn-update" style="padding:6px 12px; font-size:12px;">
                                        View Proof
                                    </a>
                                <?php else: ?>
                                    <span style="color:#999;">No Proof</span>
                                <?php endif; ?>
                            </td>

                            <!-- Approve / Reject Payment -->
                            <td>
                                <form method="POST" style="display:flex; gap:8px;">
                                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                    <input type="hidden" name="payment_status" id="payment_status_<?= $o['id'] ?>">

                                    <button type="submit" name="update_payment" class="btn-approve"
                                        onclick="document.getElementById('payment_status_<?= $o['id'] ?>').value='Approved'">
                                        Approve
                                    </button>

                                    <button type="submit" name="update_payment" class="btn-reject"
                                        onclick="document.getElementById('payment_status_<?= $o['id'] ?>').value='Rejected'">
                                        Reject
                                    </button>
                                </form>
                            </td>

                            <!-- Order Status -->
                            <td class="status-text"><?= htmlspecialchars($o['status']) ?></td>

                            <td>
                                <form method="POST" style="display:flex; gap:10px;">
                                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                    <select name="status">
                                        <option value="Pending" <?= $o['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="Preparing" <?= $o['status'] == 'Preparing' ? 'selected' : '' ?>>Preparing</option>
                                        <option value="Ready" <?= $o['status'] == 'Ready' ? 'selected' : '' ?>>Ready</option>
                                        <option value="Completed" <?= $o['status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                                    </select>
                                    <button type="submit" name="update_status" class="btn-update">Update</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="12" style="padding:40px; text-align:center; color:#636e72;">No orders found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>