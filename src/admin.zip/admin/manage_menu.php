<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];

// Fetch Admin Canteen
$stmt = $pdo->prepare("SELECT canteen_id FROM users WHERE id = ?");
$stmt->execute([$admin_id]);
$canteen_id = $stmt->fetchColumn();

if (!$canteen_id) {
    die("Admin canteen not found.");
}

$stmt = $pdo->prepare("SELECT name FROM canteens WHERE id = ?");
$stmt->execute([$canteen_id]);
$canteen_name = $stmt->fetchColumn();

// Add Menu Item Logic
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_item'])) {
    $img_path = '../assets/images/default.jpg';

    if (isset($_FILES['item_image']) && $_FILES['item_image']['error'] === 0) {
        $upload_dir = '../assets/images/menu/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_ext = strtolower(pathinfo($_FILES['item_image']['name'], PATHINFO_EXTENSION));
        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($file_ext, $allowed_exts)) {
            $new_filename = "menu_" . time() . "_" . uniqid() . "." . $file_ext;
            $target_file = $upload_dir . $new_filename;

            if (move_uploaded_file($_FILES['item_image']['tmp_name'], $target_file)) {
                $img_path = $target_file;
            }
        }
    }

    $stmt = $pdo->prepare("INSERT INTO menu_items (canteen_id, category, name, price, availability, image_url) VALUES (?, ?, ?, ?, 1, ?)");
    $stmt->execute([
        $canteen_id,
        trim($_POST['category']),
        trim($_POST['name']),
        $_POST['price'],
        $img_path
    ]);

    header("Location: manage_menu.php?success=1");
    exit();
}

// Edit Menu Item Logic
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_item'])) {
    $item_id = $_POST['item_id'];

    if (isset($_FILES['edit_image']) && $_FILES['edit_image']['error'] === 0) {
        $upload_dir = '../assets/images/menu/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_ext = strtolower(pathinfo($_FILES['edit_image']['name'], PATHINFO_EXTENSION));
        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($file_ext, $allowed_exts)) {
            $new_filename = "menu_" . time() . "_" . uniqid() . "." . $file_ext;
            $target_file = $upload_dir . $new_filename;

            if (move_uploaded_file($_FILES['edit_image']['tmp_name'], $target_file)) {
                $stmt = $pdo->prepare("UPDATE menu_items SET name = ?, price = ?, category = ?, image_url = ? WHERE id = ? AND canteen_id = ?");
                $stmt->execute([
                    trim($_POST['name']),
                    $_POST['price'],
                    trim($_POST['category']),
                    $target_file,
                    $item_id,
                    $canteen_id
                ]);

                header("Location: manage_menu.php?updated=1");
                exit();
            }
        }
    }

    $stmt = $pdo->prepare("UPDATE menu_items SET name = ?, price = ?, category = ? WHERE id = ? AND canteen_id = ?");
    $stmt->execute([
        trim($_POST['name']),
        $_POST['price'],
        trim($_POST['category']),
        $item_id,
        $canteen_id
    ]);

    header("Location: manage_menu.php?updated=1");
    exit();
}

// Delete Item
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM menu_items WHERE id = ? AND canteen_id = ?");
    $stmt->execute([$_GET['delete'], $canteen_id]);
    header("Location: manage_menu.php?deleted=1");
    exit();
}

// Toggle Availability
if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $stmt = $pdo->prepare("UPDATE menu_items SET availability = NOT availability WHERE id = ? AND canteen_id = ?");
    $stmt->execute([$_GET['toggle'], $canteen_id]);
    header("Location: manage_menu.php");
    exit();
}

// Fetch Items
$stmt = $pdo->prepare("SELECT * FROM menu_items WHERE canteen_id = ? ORDER BY id DESC");
$stmt->execute([$canteen_id]);
$menu_items = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Menu | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root { --primary: #e67e22; --secondary: #1a1a1a; --bg: #f8fafc; --sidebar-width: 280px; }
        * { box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; display: flex; background: var(--bg); margin: 0; }
        
        .sidebar { width: var(--sidebar-width); background: var(--secondary); color: white; height: 100vh; padding: 40px 24px; position: fixed; left: 0; top: 0; z-index: 100; }
        .logo { font-size: 32px; font-weight: 800; color: #ffffff; margin-bottom: 5px; text-decoration: none; display: block; }
        .logo span { color: var(--primary); }
        
        .canteen-badge { background: rgba(230, 126, 34, 0.2); color: var(--primary); padding: 5px 12px; border-radius: 8px; font-size: 11px; font-weight: 800; margin: 10px 0 40px 0; display: inline-block; text-transform: uppercase; }
        .sidebar a { display: block; color: #94a3b8; text-decoration: none; padding: 14px 16px; margin-bottom: 8px; border-radius: 12px; font-weight: 600; transition: 0.2s; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.05); color: white; }
        
        .main { margin-left: var(--sidebar-width); padding: 40px 60px; width: calc(100% - var(--sidebar-width)); }
        .card { background: white; padding: 30px; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); border: 1px solid #f1f5f9; margin-bottom: 30px; }
        
        .alert { padding: 15px; border-radius: 12px; margin-bottom: 20px; font-weight: 600; font-size: 14px; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }

        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; font-size: 12px; text-transform: uppercase; color: #636e72; padding: 15px; border-bottom: 2px solid #f1f5f9; letter-spacing: 0.5px; }
        td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; vertical-align: middle; }
        
        .btn-ui { padding: 10px 18px; border-radius: 10px; font-weight: 700; font-size: 12px; border: none; cursor: pointer; text-decoration: none; transition: 0.3s; }
        .btn-edit { background: #eff6ff; color: #2563eb; }
        .btn-edit:hover { background: #2563eb; color: white; }
        .btn-delete { background: #fef2f2; color: #ef4444; }
        .btn-delete:hover { background: #ef4444; color: white; }
        
        .thumbnail { width: 60px; height: 60px; border-radius: 12px; object-fit: cover; border: 1px solid #eee; }
        input, select { padding:12px; border-radius:10px; border:1px solid #ddd; font-family: inherit; outline: none; width: 100%; }
        
        #editModal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 1000; backdrop-filter: blur(4px); }
        .modal-box { background: white; padding: 40px; border-radius: 24px; width: 500px; box-shadow: 0 20px 50px rgba(0,0,0,0.2); }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <div class="canteen-badge"><?= htmlspecialchars($canteen_name) ?></div>
        <nav>
            <a href="dashboard.php">Live Orders</a>
            <a href="manage_menu.php" class="active">Menu Management</a>
            <a href="reports.php">Sales Reports</a>
            <a href="../logout.php" style="color:#ef4444; margin-top:50px;">Logout</a>
        </nav>
    </div>
    
    <div class="main">
        <h1 style="margin-top:0; font-weight: 800;">Menu Management</h1>

        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">✅ Item added successfully!</div>
        <?php elseif (isset($_GET['updated'])): ?>
            <div class="alert alert-success">✨ Item updated successfully!</div>
        <?php elseif (isset($_GET['deleted'])): ?>
            <div class="alert alert-success">🗑️ Item deleted successfully!</div>
        <?php endif; ?>
        
        <div class="card">
            <h3 style="margin-top:0; color: var(--secondary);">Add New Item</h3>
            <form method="POST" enctype="multipart/form-data" style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:15px;">
                <input type="text" name="name" placeholder="Dish Name" required>
                <input type="number" step="0.01" name="price" placeholder="Price (₹)" required>
                <select name="category">
                    <option value="Snacks">Snacks</option>
                    <option value="Beverages">Beverages</option>
                    <option value="Fruits">Fruits</option>
                    <option value="Juice">Juice</option>
                    <option value="Desserts">Desserts</option>
                    <option value="Gujarati">Gujarati</option>
                    <option value="Meals">Full Meals</option>
                </select>
                <input type="file" name="item_image" accept="image/*" required style="grid-column: span 3;">
                <button type="submit" name="add_item" style="grid-column: span 3; background: var(--primary); color:white; padding:15px; border-radius:12px; font-weight:700; border:none; cursor:pointer;">+ Add to Menu</button>
            </form>
        </div>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Availability</th>
                        <th style="text-align: center;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($menu_items as $item): ?>
                    <tr>
                        <td><img src="<?= htmlspecialchars($item['image_url']) ?>" class="thumbnail" onerror="this.src='../assets/images/default.jpg'"></td>
                        <td><strong><?= htmlspecialchars($item['name']) ?></strong><br><small style="color:#64748b"><?= htmlspecialchars($item['category']) ?></small></td>
                        <td><strong style="font-size: 16px;">₹<?= number_format($item['price'], 2) ?></strong></td>
                        <td>
                            <a href="manage_menu.php?toggle=<?= $item['id'] ?>" style="text-decoration:none; font-weight:800; font-size: 12px; color:<?= $item['availability'] ? '#10b981' : '#ef4444' ?>">
                                <?= $item['availability'] ? '● IN STOCK' : '○ SOLD OUT' ?>
                            </a>
                        </td>
                        <td>
                            <div style="display:flex; gap:10px; justify-content:center;">
                                <button class="btn-ui btn-edit" onclick='openEdit(<?= json_encode($item) ?>)'>Edit</button>
                                <a href="manage_menu.php?delete=<?= $item['id'] ?>" class="btn-ui btn-delete" onclick="return confirm('Remove this item permanently?')">Delete</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="editModal">
        <div class="modal-box">
            <h3 style="margin-top:0; font-weight: 800;">Edit Menu Item</h3>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="item_id" id="edit_id">
                
                <label style="font-size: 11px; font-weight: 700; color: #64748b;">ITEM NAME</label>
                <input type="text" name="name" id="edit_name" required style="margin-bottom:15px;">
                
                <label style="font-size: 11px; font-weight: 700; color: #64748b;">PRICE (INR)</label>
                <input type="number" step="0.01" name="price" id="edit_price" required style="margin-bottom:15px;">
                
                <label style="font-size: 11px; font-weight: 700; color: #64748b;">UPDATE IMAGE (Optional)</label>
                <input type="file" name="edit_image" accept="image/*" style="margin-bottom:15px;">
                
                <label style="font-size: 11px; font-weight: 700; color: #64748b;">CATEGORY</label>
                <select name="category" id="edit_cat" style="margin-bottom:20px;">
                    <option value="Snacks">Snacks</option>
                    <option value="Beverages">Beverages</option>
                    <option value="Fruits">Fruits</option>
                    <option value="Juice">Juice</option>
                    <option value="Desserts">Desserts</option>
                    <option value="Gujarati">Gujarati</option>
                    <option value="Meals">Full Meals</option>
                </select>
                
                <button type="submit" name="update_item" style="width:100%; background: var(--primary); color:white; padding:14px; border-radius:12px; border:none; font-weight:700; cursor:pointer;">Update Item</button>
                <button type="button" onclick="document.getElementById('editModal').style.display='none'" style="width:100%; background:none; border:none; color:#ef4444; margin-top:10px; cursor:pointer; font-weight:700;">Cancel</button>
            </form>
        </div>
    </div>

    <script>
        function openEdit(item) {
            document.getElementById('edit_id').value = item.id;
            document.getElementById('edit_name').value = item.name;
            document.getElementById('edit_price').value = item.price;
            document.getElementById('edit_cat').value = item.category;
            document.getElementById('editModal').style.display = 'flex';
        }
    </script>
</body>
</html>