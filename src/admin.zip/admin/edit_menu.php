<?php
require "../config/db.php";
require "../includes/auth.php";
checkLogin();
checkRole('admin');
include "../includes/header.php";

$id = $_GET['id'];

if(isset($_POST['update'])){
    $name = $_POST['name'];
    $price = $_POST['price'];
    $availability = $_POST['availability'];

    $stmt = $conn->prepare("UPDATE menu_items SET name=?, price=?, availability=? WHERE id=?");
    $stmt->execute([$name,$price,$availability,$id]);

    header("Location: manage_menu.php");
}

$item = $conn->query("SELECT * FROM menu_items WHERE id=$id")->fetch();
?>

<form method="POST">
    <input name="name" value="<?= $item['name'] ?>" required>
    <input name="price" value="<?= $item['price'] ?>" required>
    <select name="availability">
        <option value="1">Available</option>
        <option value="0">Not Available</option>
    </select>
    <button name="update" class="btn">Update</button>
</form>