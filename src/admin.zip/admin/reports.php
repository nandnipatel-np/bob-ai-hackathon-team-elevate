<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT canteen_id FROM users WHERE id = ?");
$stmt->execute([$admin_id]);
$canteen_id = $stmt->fetchColumn();

if (!$canteen_id) {
    die("Admin canteen not configured.");
}

$stmt = $pdo->prepare("SELECT name FROM canteens WHERE id = ?");
$stmt->execute([$canteen_id]);
$canteen_name = $stmt->fetchColumn();

// Handle selected date
$target_date = isset($_GET['report_date']) ? $_GET['report_date'] : date('Y-m-d');

// Sales Summary
$summary_stmt = $pdo->prepare("
    SELECT COUNT(id) AS total_orders, SUM(total_amount) AS total_revenue 
    FROM orders 
    WHERE canteen_id = ? AND DATE(order_date) = ? AND status = 'Completed'
");
$summary_stmt->execute([$canteen_id, $target_date]);
$summary = $summary_stmt->fetch();

// Item-wise breakdown with customer_id added
$item_stmt = $pdo->prepare("
    SELECT 
        u.customer_id,
        u.name AS customer_name, 
        mi.name AS menu_item_name, 
        SUM(od.quantity) AS total_qty, 
        SUM(od.subtotal) AS item_revenue
    FROM order_details od
    JOIN menu_items mi ON od.item_id = mi.id
    JOIN orders o ON od.order_id = o.id
    JOIN users u ON o.user_id = u.id
    WHERE o.canteen_id = ? AND DATE(o.order_date) = ? AND o.status = 'Completed'
    GROUP BY u.id, mi.id
    ORDER BY total_qty DESC
");
$item_stmt->execute([$canteen_id, $target_date]);
$item_sales = $item_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

    <style>
        :root { 
            --primary: #e67e22; 
            --secondary: #1a1a1a; 
            --bg: #f8fafc; 
            --sidebar-width: 280px; 
            --success: #27ae60;
        }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: 'Plus Jakarta Sans', sans-serif; display: flex; background: var(--bg); color: #2d3436; }
        
        .sidebar { width: var(--sidebar-width); background: var(--secondary); color: white; height: 100vh; padding: 40px 24px; position: fixed; left: 0; top: 0; }
        .logo { font-size: 32px; font-weight: 800; color: #ffffff; margin-bottom: 5px; text-decoration: none; display: block; }
        .logo span { color: var(--primary); }
        
        .canteen-badge { background: rgba(230, 126, 34, 0.2); color: var(--primary); padding: 5px 12px; border-radius: 8px; font-size: 11px; font-weight: 800; margin: 10px 0 40px 0; display: inline-block; text-transform: uppercase; }
        .sidebar a { display: block; color: #94a3b8; text-decoration: none; padding: 14px 16px; margin-bottom: 8px; border-radius: 12px; font-weight: 600; transition: 0.2s; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.05); color: white; }

        .main { margin-left: var(--sidebar-width); padding: 40px 60px; width: calc(100% - var(--sidebar-width)); }

        .header-actions { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        .action-buttons { display: flex; gap: 12px; }
        .btn-action { padding: 10px 20px; border-radius: 10px; font-family: inherit; font-weight: 700; font-size: 14px; cursor: pointer; border: none; display: flex; align-items: center; gap: 8px; transition: 0.2s; }
        .btn-print { background: white; color: var(--secondary); border: 1px solid #e2e8f0; }
        .btn-print:hover { background: #f1f5f9; transform: translateY(-2px); }
        .btn-pdf { background: var(--primary); color: white; box-shadow: 0 4px 12px rgba(230,126,34,0.2); }
        .btn-pdf:hover { background: #d35400; transform: translateY(-2px); }

        .filter-card { background: white; padding: 25px 30px; border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.02); display: flex; align-items: center; gap: 20px; margin-bottom: 30px; border: 1px solid #f1f5f9; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 30px; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); border-bottom: 4px solid var(--primary); text-align: center; }
        .stat-card h3 { font-size: 36px; margin: 10px 0; color: var(--secondary); font-weight: 800; }
        
        table { width: 100%; background: white; border-radius: 24px; border-collapse: collapse; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.04); border: 1px solid #f1f5f9; }
        th { text-align: left; background: #f8fafc; padding: 20px; font-size: 12px; text-transform: uppercase; color: #636e72; letter-spacing: 0.5px; }
        td { padding: 20px; border-bottom: 1px solid #f1f5f9; font-size: 15px; }
        
        .btn-filter { background: var(--primary); color: white; border: none; padding: 12px 24px; border-radius: 12px; font-weight: 700; cursor: pointer; transition: 0.3s; }
        .btn-filter:hover { background: #d35400; transform: translateY(-1px); }
        
        input[type="date"] { padding: 10px 15px; border-radius: 10px; border: 1px solid #e2e8f0; font-family: inherit; font-weight: 600; color: var(--secondary); outline: none; }
        input[type="date"]:focus { border-color: var(--primary); }

        @media print {
            body { background-color: white !important; }
            .sidebar { display: none !important; }
            .main { margin-left: 0 !important; padding: 0 !important; width: 100% !important; }
            .header-actions .action-buttons, .filter-card { display: none !important; }
            .stat-card, table { 
                box-shadow: none !important; 
                border: 1px solid #e2e8f0 !important; 
                break-inside: avoid;
            }
            .print-only-title { display: block !important; margin-bottom: 20px; color: var(--secondary); }
        }

        .print-only-title { display: none; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <div class="canteen-badge"><?= htmlspecialchars($canteen_name) ?></div>
        <nav>
            <a href="dashboard.php">Live Orders</a>
            <a href="manage_menu.php">Menu Management</a>
            <a href="reports.php" class="active">Sales Reports</a>
            <a href="../logout.php" style="color:#ef4444; margin-top:50px;">Logout</a>
        </nav>
    </div>

    <div class="main">
        <div class="header-actions">
            <h1 style="margin:0; font-weight: 800; font-size: 32px;">Sales Insights</h1>
            
            <div class="action-buttons">
                <button onclick="window.print()" class="btn-action btn-print">Print</button>
                <button onclick="downloadPDF()" class="btn-action btn-pdf">Download PDF</button>
            </div>
        </div>
        
        <form method="GET" class="filter-card">
            <span style="font-weight: 700; color: #636e72;">Select Report Date:</span>
            <input type="date" name="report_date" value="<?= htmlspecialchars($target_date) ?>">
            <button type="submit" class="btn-filter">Generate Report</button>
        </form>

        <div id="report-content">
            <div class="print-only-title">
                <h2 style="margin-bottom: 5px;"><?= htmlspecialchars($canteen_name) ?> - Sales Report</h2>
                <p style="margin-top: 0; color: #636e72;">Report Date: <?= date('d M, Y', strtotime($target_date)) ?></p>
            </div>

            <div class="grid">
                <div class="stat-card">
                    <p style="text-transform: uppercase; font-size: 12px; font-weight: 800; color: #636e72; margin:0; letter-spacing: 1px;">Orders Completed</p>
                    <h3><?= $summary['total_orders'] ?? 0 ?></h3>
                </div>
                <div class="stat-card" style="border-color: var(--success);">
                    <p style="text-transform: uppercase; font-size: 12px; font-weight: 800; color: #636e72; margin:0; letter-spacing: 1px;">Total Revenue</p>
                    <h3 style="color: var(--success);">₹<?= number_format($summary['total_revenue'] ?? 0, 2) ?></h3>
                </div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Customer ID</th>
                        <th>Customer Name</th>
                        <th>Menu Item</th>
                        <th>Qty Sold</th>
                        <th>Revenue Generated</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($item_sales) > 0): ?>
                        <?php foreach ($item_sales as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['customer_id'] ?? '-') ?></td>
                            <td><strong><?= htmlspecialchars($row['customer_name'] ?? 'Guest') ?></strong></td>
                            <td><strong><?= htmlspecialchars($row['menu_item_name']) ?></strong></td>
                            <td><span style="background: #eff6ff; color: #2563eb; padding: 5px 12px; border-radius: 8px; font-weight: 700; font-size: 13px;"><?= $row['total_qty'] ?> units</span></td>
                            <td><strong style="font-size: 16px;">₹<?= number_format($row['item_revenue'], 2) ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5" style="text-align:center; padding: 60px; color: #636e72; font-weight: 600;">No completed sales records found for <?= date('d M, Y', strtotime($target_date)) ?>.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function downloadPDF() {
            const element = document.getElementById('report-content');
            const printTitle = element.querySelector('.print-only-title');
            printTitle.style.display = 'block';

            const opt = {
                margin: 0.5,
                filename: 'Sales_Report_<?= htmlspecialchars($target_date) ?>.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2, useCORS: true },
                jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
            };

            html2pdf().set(opt).from(element).save().then(() => {
                printTitle.style.display = 'none';
            });
        }
    </script>
</body>
</html>