<?php
require "../config/db.php";
require "../includes/auth.php";
checkLogin();
checkRole('admin');

$id = $_GET['id'];
$conn->prepare("DELETE FROM menu_items WHERE id=?")->execute([$id]);

header("Location: manage_menu.php");