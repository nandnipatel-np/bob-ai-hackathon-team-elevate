<?php
session_start();
require_once '../config/db.php';

// Set Timezone
date_default_timezone_set('Asia/Kolkata');

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['user_id'];

// Get Admin's Canteen ID
$stmt = $pdo->prepare("SELECT canteen_id FROM users WHERE id = ?");
$stmt->execute([$admin_id]);
$canteen_id = $stmt->fetchColumn();

if (!$canteen_id) {
    die("<div style='padding:50px; text-align:center;'><h2>Account Not Configured</h2><a href='../logout.php'>Logout</a></div>");
}

// Handle Order Status Update
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];

    $stmt_update = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ? AND canteen_id = ?");
    $stmt_update->execute([$new_status, $order_id, $canteen_id]);

    header("Location: dashboard.php?msg=updated");
    exit();
}

// Get Canteen Name
$stmt = $pdo->prepare("SELECT name FROM canteens WHERE id = ?");
$stmt->execute([$canteen_id]);
$canteen_name = $stmt->fetchColumn();

// Fetch Orders
$stmt = $pdo->prepare("
    SELECT 
        o.*, 
        u.name AS customer_name, 
        p.payment_status,
        p.transaction_proof
    FROM orders o
    JOIN users u ON o.user_id = u.id
    LEFT JOIN payments p ON o.id = p.order_id
    WHERE o.canteen_id = ?
    ORDER BY o.order_date DESC, o.id DESC
");
$stmt->execute([$canteen_id]);
$orders = $stmt->fetchAll();

/**
 * Resolve Proof File Path
 * Works for:
 * - proof_123.webp
 * - assets/images/proofs/proof_123.webp
 */
function getProofPath($proofFile) {
    if (empty($proofFile)) {
        return [null, null];
    }

    $proofFile = trim($proofFile);
    $fileName = basename($proofFile);

    // Absolute server file path
    $serverPath = __DIR__ . "/../assets/images/proofs/" . $fileName;

    // Browser path
    $browserPath = "../assets/images/proofs/" . $fileName;

    if (file_exists($serverPath)) {
        return [$serverPath, $browserPath];
    }

    return [null, null];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root { 
            --primary: #e67e22; 
            --secondary: #1a1a1a; 
            --bg: #f8fafc; 
            --sidebar-width: 280px; 
        }

        * { box-sizing: border-box; }

        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            display: flex; 
            background: var(--bg); 
            margin: 0; 
        }
        
        .sidebar { 
            width: var(--sidebar-width); 
            background: var(--secondary); 
            color: white; 
            height: 100vh; 
            padding: 40px 24px; 
            position: fixed; 
            left: 0; 
            top: 0; 
            z-index: 100; 
        }

        .logo { 
            font-size: 32px; 
            font-weight: 800; 
            color: #ffffff; 
            margin-bottom: 5px; 
            text-decoration: none; 
            display: block; 
        }

        .logo span { color: var(--primary); }
        
        .canteen-badge { 
            background: rgba(230, 126, 34, 0.2); 
            color: var(--primary); 
            padding: 5px 12px; 
            border-radius: 8px; 
            font-size: 11px; 
            font-weight: 800; 
            margin: 10px 0 40px 0; 
            display: inline-block; 
            text-transform: uppercase; 
        }

        .sidebar a { 
            display: block; 
            color: #94a3b8; 
            text-decoration: none; 
            padding: 14px 16px; 
            margin-bottom: 8px; 
            border-radius: 12px; 
            font-weight: 600; 
            transition: 0.2s; 
        }

        .sidebar a:hover, 
        .sidebar a.active { 
            background: rgba(255,255,255,0.05); 
            color: white; 
        }

        .main { 
            margin-left: var(--sidebar-width); 
            padding: 40px 60px; 
            width: calc(100% - var(--sidebar-width)); 
        }

        .card { 
            background: white; 
            padding: 30px; 
            border-radius: 24px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.04); 
            border: 1px solid #f1f5f9; 
            margin-bottom: 30px; 
            overflow-x: auto; 
        }
        
        table { 
            width: 100%; 
            border-collapse: collapse; 
            min-width: 1200px; 
        }

        th { 
            text-align: left; 
            font-size: 11px; 
            text-transform: uppercase; 
            color: #636e72; 
            padding: 15px; 
            border-bottom: 2px solid #f1f5f9; 
            letter-spacing: 0.5px; 
            white-space: nowrap;
        }

        td { 
            padding: 15px; 
            border-bottom: 1px solid #f1f5f9; 
            font-size: 14px; 
            vertical-align: middle; 
        }

        .nowrap {
            white-space: nowrap;
        }

        .btn-update { 
            background: var(--primary); 
            color: white; 
            border: none; 
            padding: 10px 18px; 
            border-radius: 10px; 
            font-weight: 700; 
            cursor: pointer; 
            transition: 0.3s; 
        }

        .btn-update:hover { 
            background: #d35400; 
            transform: translateY(-1px); 
        }
        
        select { 
            padding: 10px; 
            border-radius: 10px; 
            border: 1px solid #ddd; 
            font-family: inherit; 
            outline: none; 
            font-weight: 600; 
        }

        .status-text { 
            font-weight: 800; 
            font-size: 11px; 
            text-transform: uppercase; 
            color: var(--secondary); 
            white-space: nowrap;
        }

        .proof-btn {
            display: inline-block;
            background: #1e293b;
            color: white;
            padding: 8px 14px;
            border-radius: 10px;
            text-decoration: none;
            font-size: 12px;
            font-weight: 700;
            transition: 0.2s;
            white-space: nowrap;
            border: none;
            cursor: pointer;
        }

        .proof-btn:hover {
            background: var(--primary);
        }

        .no-proof {
            color: #94a3b8;
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }

        .missing-proof {
            color: #dc2626;
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }

        .success-msg {
            background: #dcfce7;
            color: #166534;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 700;
            font-size: 14px;
        }

        /* Proof Modal */
        .proof-modal {
            display: none;
            position: fixed;
            z-index: 9999;
            inset: 0;
            background: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
        }

        .proof-modal-content {
            background: #fff;
            padding: 15px;
            border-radius: 16px;
            max-width: 80%;
            max-height: 85vh;
            position: relative;
        }

        .proof-modal-content img {
            max-width: 100%;
            max-height: 75vh;
            border-radius: 10px;
        }

        .close-proof {
            position: absolute;
            top: 8px;
            right: 15px;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <div class="canteen-badge"><?= htmlspecialchars($canteen_name) ?></div>
        <nav>
            <a href="dashboard.php" class="active">Live Orders</a>
            <a href="manage_menu.php">Menu Management</a>
            <a href="reports.php">Sales Reports</a>
            <a href="../logout.php" style="color:#ef4444; margin-top:50px;">Logout</a>
        </nav>
    </div>
    
    <div class="main">
        <h1 style="margin-top:0; font-weight: 800;">Incoming Orders</h1>

        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'updated'): ?>
            <div class="success-msg">Order status updated successfully.</div>
        <?php endif; ?>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Order Date</th>
                        <th>Order Time</th>
                        <th>Amount</th>
                        <th>Pickup</th>
                        <th>Payment</th>
                        <th>Verification Proof</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($orders) > 0): ?>
                        <?php foreach($orders as $o): 
                            $raw_date = !empty($o['order_date']) ? $o['order_date'] : 'now';
                            [$proofServerPath, $proofBrowserPath] = getProofPath($o['transaction_proof'] ?? '');

                            // SMART PAYMENT LOGIC
                            if (!empty($o['transaction_proof']) && $proofBrowserPath) {
                                $paymentText = 'Paid';
                                $paymentColor = '#16a34a';
                            } else {
                                $paymentText = 'Pending';
                                $paymentColor = '#e67e22';
                            }
                        ?>
                        <tr>
                            <td class="nowrap"><strong>#<?= htmlspecialchars($o['order_number']) ?></strong></td>
                            <td class="nowrap"><?= htmlspecialchars($o['customer_name'] ?? 'Guest') ?></td>
                            
                            <td class="nowrap" style="font-weight: 600; color: #636e72;">
                                <?= date('d M, Y', strtotime($raw_date)) ?>
                            </td>

                            <td class="nowrap" style="font-weight: 700; color: var(--primary);">
                                <?= date('h:i A', strtotime($raw_date)) ?>
                            </td>

                            <td class="nowrap">
                                <strong style="font-size: 16px;">₹<?= number_format($o['total_amount'], 2) ?></strong>
                            </td>
                            
                            <td class="nowrap">
                                <span style="font-size: 12px; background: #f1f5f9; padding: 4px 8px; border-radius: 6px; font-weight: 700; white-space: nowrap;">
                                    <?= !empty($o['scheduled_pickup_time']) ? date('h:i A', strtotime($o['scheduled_pickup_time'])) : 'N/A' ?>
                                </span>
                            </td>

                            <td class="nowrap">
                                <span style="font-size: 12px; font-weight: 700; color: <?= $paymentColor ?>;">
                                    <?= htmlspecialchars($paymentText) ?>
                                </span>
                            </td>

                            <td class="nowrap">
                                <?php if (!empty($o['transaction_proof'])): ?>
                                    <?php if ($proofBrowserPath): ?>
                                        <button type="button" class="proof-btn" onclick="openProof('<?= htmlspecialchars($proofBrowserPath) ?>')">View Proof</button>
                                    <?php else: ?>
                                        <span class="missing-proof">File Missing</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="no-proof">No Proof</span>
                                <?php endif; ?>
                            </td>

                            <td class="status-text"><?= htmlspecialchars($o['status']) ?></td>

                            <td class="nowrap">
                                <form method="POST" style="display:flex; gap:10px;">
                                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                    <select name="status">
                                        <option value="Pending" <?= $o['status']=='Pending'?'selected':'' ?>>Pending</option>
                                        <option value="Preparing" <?= $o['status']=='Preparing'?'selected':'' ?>>Preparing</option>
                                        <option value="Ready" <?= $o['status']=='Ready'?'selected':'' ?>>Ready</option>
                                        <option value="Completed" <?= $o['status']=='Completed'?'selected':'' ?>>Completed</option>
                                        <option value="Cancelled" <?= $o['status']=='Cancelled'?'selected':'' ?>>Cancelled</option>
                                    </select>
                                    <button type="submit" name="update_status" class="btn-update">Update</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" style="padding:40px; text-align:center; color:#636e72; font-weight: 600;">
                                No incoming orders at the moment.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Proof Modal -->
    <div id="proofModal" class="proof-modal">
        <div class="proof-modal-content">
            <span class="close-proof" onclick="closeProof()">&times;</span>
            <img id="proofImage" src="" alt="Payment Proof">
        </div>
    </div>

    <script>
    function openProof(imagePath) {
        document.getElementById("proofImage").src = imagePath;
        document.getElementById("proofModal").style.display = "flex";
    }

    function closeProof() {
        document.getElementById("proofModal").style.display = "none";
        document.getElementById("proofImage").src = "";
    }

    // Close when clicking outside
    window.onclick = function(e) {
        const modal = document.getElementById("proofModal");
        if (e.target === modal) {
            closeProof();
        }
    }
    </script>

</body>
</html>