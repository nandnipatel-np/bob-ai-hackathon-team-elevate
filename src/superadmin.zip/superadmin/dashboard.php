<?php
session_start();
require_once '../config/db.php';

// Authentication Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login.php");
    exit();
}

// Fetch System Statistics
$total_canteens = $pdo->query("SELECT COUNT(*) FROM canteens")->fetchColumn();
$total_admins = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
// NEW: Fetch Total Customers
$total_customers = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();

// Calculate Revenue (Only for Completed/Paid orders)
$revenue_query = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE status IN ('Completed', 'Ready', 'Preparing')");
$total_revenue = $revenue_query->fetchColumn();
$total_revenue = $total_revenue ? $total_revenue : 0.00; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Overview | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
            --success: #10b981;
        }

        body { 
            margin: 0; 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: var(--bg); 
            display: flex; 
            color: var(--text-main);
        }
        
        /* Modern Sidebar */
        .sidebar { 
            width: 280px; 
            background: var(--secondary); 
            color: white; 
            height: 100vh; 
            padding: 40px 24px; 
            position: fixed; 
            box-sizing: border-box; 
        }
        
        .sidebar .logo { font-size: 32px; font-weight: 800; margin-bottom: 5px; display: block; }
        .sidebar .logo span { color: var(--primary); }
        
        .sidebar p.role-tag { 
            font-size: 11px; color: #94a3b8; font-weight: 700; text-transform: uppercase; 
            letter-spacing: 1.5px; margin-bottom: 40px; 
        }
        
        .sidebar a { 
            display: flex; align-items: center; color: #94a3b8; text-decoration: none; 
            padding: 14px 16px; margin-bottom: 8px; border-radius: 12px; font-weight: 600; transition: 0.2s; 
        }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.08); color: white; }
        .logout-btn { color: #ef4444 !important; margin-top: 50px; }

        /* Main Content */
        .main-content { margin-left: 280px; padding: 40px 60px; width: 100%; box-sizing: border-box; }
        .header { margin-bottom: 40px; }
        .header h1 { margin: 0; font-size: 32px; font-weight: 800; color: var(--secondary); }
        .header p { color: var(--text-muted); margin-top: 8px; font-weight: 500; }

        /* Stats Grid - Updated to 4 columns to fit Customers */
        .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); 
            gap: 25px; 
            margin-bottom: 40px;
        }
        .stat-card { 
            background: var(--white); padding: 30px; border-radius: 24px; 
            box-shadow: var(--shadow); text-align: center; border: 1px solid #f1f5f9;
            transition: transform 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-5px); }
        .stat-card h3 { font-size: 36px; font-weight: 800; margin: 0; color: var(--secondary); }
        .stat-card p { 
            color: var(--text-muted); margin: 10px 0 0; font-size: 12px; 
            font-weight: 700; text-transform: uppercase; letter-spacing: 1px;
        }
        .revenue-text { color: var(--success) !important; }

        /* Quick Actions */
        .action-card { background: var(--white); padding: 30px; border-radius: 24px; box-shadow: var(--shadow); border: 1px solid #f1f5f9; }
        .action-card h3 { margin-top: 0; font-size: 20px; font-weight: 800; margin-bottom: 20px; }
        .action-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; }
        .btn-action {
            display: block; text-align: center; padding: 15px; background: #f1f5f9;
            color: var(--secondary); text-decoration: none; border-radius: 12px;
            font-weight: 700; font-size: 13px; border: 1px solid #e2e8f0; transition: 0.3s;
        }
        .btn-action:hover { background: var(--primary); color: white; border-color: var(--primary); }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <p class="role-tag">Super Admin Panel</p>
        <nav>
            <a href="dashboard.php" class="active">Overview</a>
            <a href="manage_canteen.php">Manage Canteens</a>
            <a href="manage_admin.php">Manage Admins</a>
            <a href="manage_customers.php">Manage Customers</a> 
            <a href="reports.php">System Reports</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>System Overview</h1>
            <p>Monitor platform-wide statistics and operations for CCP.</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo $total_canteens; ?></h3>
                <p>Total Canteens</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $total_admins; ?></h3>
                <p>Active Admins</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $total_customers; ?></h3>
                <p>Total Customers</p>
            </div>
            <div class="stat-card">
                <h3 class="revenue-text">₹<?php echo number_format($total_revenue, 2); ?></h3>
                <p>Total Revenue (INR)</p>
            </div>
        </div>

        <div class="action-card">
            <h3>Quick Management Actions</h3>
            <div class="action-grid">
                <a href="manage_canteen.php" class="btn-action">+ Register Canteen</a>
                <a href="manage_admin.php" class="btn-action">Assign New Admin</a>
                <a href="manage_customers.php" class="btn-action">Manage All Users</a>
                <a href="reports.php" class="btn-action">View Full Analytics</a>
            </div>
        </div>
    </div>

</body>
</html>