<?php
session_start();
require_once '../config/db.php';

// Access Control
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login.php");
    exit();
}

$message = '';

// Handle Permanent Delete with Advanced Dependency Cleanup
if (isset($_GET['delete_id']) && is_numeric($_GET['delete_id'])) {
    $id = (int) $_GET['delete_id'];
    
    try {
        $pdo->beginTransaction();

        // 1. Get image path before deleting so we can remove the file from the server
        $stmtImg = $pdo->prepare("SELECT image FROM canteens WHERE id = ?");
        $stmtImg->execute([$id]);
        $canteenImg = $stmtImg->fetchColumn();

        // 2. Clear Menu Items & Order Details
        $stmtItems = $pdo->prepare("SELECT id FROM menu_items WHERE canteen_id = ?");
        $stmtItems->execute([$id]);
        $itemIds = $stmtItems->fetchAll(PDO::FETCH_COLUMN);

        if (!empty($itemIds)) {
            $placeholders = str_repeat('?,', count($itemIds) - 1) . '?';
            $stmtDetails = $pdo->prepare("DELETE FROM order_details WHERE item_id IN ($placeholders)");
            $stmtDetails->execute($itemIds);
        }

        // 3. Clear Payments
        $stmtPayments = $pdo->prepare("
            DELETE p FROM payments p
            INNER JOIN orders o ON p.order_id = o.id
            WHERE o.canteen_id = ?
        ");
        $stmtPayments->execute([$id]);

        // 4. Delete the rest
        $stmtDelItems = $pdo->prepare("DELETE FROM menu_items WHERE canteen_id = ?");
        $stmtDelItems->execute([$id]);

        $stmtUsers = $pdo->prepare("DELETE FROM users WHERE canteen_id = ? AND role = 'admin'");
        $stmtUsers->execute([$id]);

        $stmtOrders = $pdo->prepare("DELETE FROM orders WHERE canteen_id = ?");
        $stmtOrders->execute([$id]);

        $stmtCanteen = $pdo->prepare("DELETE FROM canteens WHERE id = ?");
        $stmtCanteen->execute([$id]);

        $pdo->commit();
        
        // Remove the image file from the server if it exists
        if (!empty($canteenImg) && file_exists("../assets/images/canteens/" . $canteenImg)) {
            unlink("../assets/images/canteens/" . $canteenImg);
        }

        $message = "<div class='alert success'>🗑️ Canteen and historical data removed successfully.</div>";
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "<div class='alert error'>❌ Error: Cannot delete. Data is still linked.</div>";
    }
}

// Fail-safe Toggle Logic
if (isset($_GET['toggle_id']) && isset($_GET['current_status']) && is_numeric($_GET['toggle_id'])) {
    $id = (int) $_GET['toggle_id'];
    $new_status = ($_GET['current_status'] == 1) ? 0 : 1;
   
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("UPDATE canteens SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $id]);

        try {
            $stmtUser = $pdo->prepare("UPDATE users SET status = ? WHERE canteen_id = ? AND role = 'admin'");
            $stmtUser->execute([$new_status, $id]);
        } catch (Exception $userEx) {}

        $pdo->commit();
        $status_label = ($new_status == 1) ? 'activated' : 'deactivated';
        header("Location: manage_canteen.php?msg=" . urlencode($status_label));
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "<div class='alert error'>❌ Error updating status.</div>";
    }
}

if (isset($_GET['msg'])) {
    $label = htmlspecialchars($_GET['msg']);
    if ($label === 'image_updated') {
        $message = "<div class='alert success'>✅ Canteen profile image updated successfully!</div>";
    } else {
        $message = "<div class='alert success'>✅ Canteen $label successfully!</div>";
    }
}

// --- HANDLE QUICK IMAGE UPDATE FOR EXISTING CANTEEN ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_image'])) {
    $update_id = (int) $_POST['canteen_id'];
    
    if (isset($_FILES['canteen_image']) && $_FILES['canteen_image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../assets/images/canteens/';
        if (!is_dir($uploadDir)) { mkdir($uploadDir, 0777, true); }

        $ext = strtolower(pathinfo($_FILES['canteen_image']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($ext, $allowed)) {
            $newFileName = 'canteen_' . $update_id . '_' . time() . '.' . $ext;
            
            if (move_uploaded_file($_FILES['canteen_image']['tmp_name'], $uploadDir . $newFileName)) {
                // Update DB
                $stmt = $pdo->prepare("UPDATE canteens SET image = ? WHERE id = ?");
                $stmt->execute([$newFileName, $update_id]);
                
                header("Location: manage_canteen.php?msg=image_updated");
                exit();
            } else {
                $message = "<div class='alert error'>❌ Failed to move uploaded image.</div>";
            }
        } else {
            $message = "<div class='alert error'>❌ Invalid format. Use JPG, PNG, or WEBP.</div>";
        }
    }
}

// --- UPDATED VALIDATION LOGIC FOR NEW CANTEEN (WITH IMAGE) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_canteen'])) {
    $name = trim($_POST['name']);
    $location = trim($_POST['location']);
    
    // Pattern: Must contain at least one letter [a-zA-Z]
    $valid_pattern = "/^(?=.*[a-zA-Z])[a-zA-Z0-9\s\-&,()]+$/";

    if (empty($name) || empty($location)) {
        $message = "<div class='alert error'>⚠️ All fields are required.</div>";
    } elseif (is_numeric($name) || is_numeric($location)) {
        $message = "<div class='alert error'>⚠️ Name and Location cannot be just numbers.</div>";
    } elseif (!preg_match($valid_pattern, $name) || !preg_match($valid_pattern, $location)) {
        $message = "<div class='alert error'>⚠️ Invalid format. Name and Location must contain letters.</div>";
    } else {
        // Handle initial image upload if provided
        $imageName = null;
        if (isset($_FILES['canteen_image']) && $_FILES['canteen_image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = '../assets/images/canteens/';
            if (!is_dir($uploadDir)) { mkdir($uploadDir, 0777, true); }
            
            $ext = strtolower(pathinfo($_FILES['canteen_image']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp'];
            
            if (in_array($ext, $allowed)) {
                $imageName = 'canteen_new_' . time() . '.' . $ext;
                move_uploaded_file($_FILES['canteen_image']['tmp_name'], $uploadDir . $imageName);
            }
        }

        $stmt = $pdo->prepare("INSERT INTO canteens (name, location, status, image) VALUES (?, ?, 1, ?)");
        if ($stmt->execute([$name, $location, $imageName])) {
            $message = "<div class='alert success'>✅ Canteen registered successfully!</div>";
        } else {
            $message = "<div class='alert error'>❌ Failed to register canteen.</div>";
        }
    }
}

$canteens = $pdo->query("SELECT * FROM canteens ORDER BY name ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Canteens | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22; --secondary: #1a1a1a; --bg: #f8fafc;
            --white: #ffffff; --text-main: #2d3436; --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04); --danger: #ef4444;
        }
        body { margin: 0; font-family: 'Plus Jakarta Sans', sans-serif; background-color: var(--bg); display: flex; }
        .sidebar { width: 280px; background: var(--secondary); color: white; height: 100vh; padding: 40px 24px; position: fixed; box-sizing: border-box; }
        .sidebar h2 { font-size: 32px; font-weight: 800; margin-bottom: 40px; margin-top: 0; }
        .sidebar h2 span { color: var(--primary); }
        .sidebar a { display: flex; align-items: center; color: #94a3b8; text-decoration: none; padding: 14px 16px; margin-bottom: 8px; border-radius: 12px; font-weight: 600; transition: 0.2s; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.05); color: white; }
        .main-content { margin-left: 280px; padding: 40px 60px; width: 100%; box-sizing: border-box; }
        .content-card { background: var(--white); padding: 30px; border-radius: 24px; box-shadow: var(--shadow); margin-bottom: 30px; border: 1px solid #f1f5f9; overflow-x: auto; }
        h1 { font-size: 28px; font-weight: 800; color: var(--secondary); margin-top: 0; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { font-size: 13px; font-weight: 700; color: var(--text-muted); display: block; margin-bottom: 8px; text-transform: uppercase; }
        input[type="text"], input[type="file"] { width: 100%; padding: 14px; border: 1px solid #e2e8f0; border-radius: 12px; font-size: 14px; box-sizing: border-box; outline: none; transition: 0.2s; background: white; }
        input[type="text"]:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(230, 126, 34, 0.1); }
        input[type="file"] { padding: 10px; color: #64748b; }
        input[type="file"]::file-selector-button { background: #f1f5f9; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 700; color: #1e293b; cursor: pointer; margin-right: 15px; transition: 0.2s; }
        input[type="file"]::file-selector-button:hover { background: #e2e8f0; }
        
        .btn-add { background: var(--primary); color: white; border: none; padding: 14px 28px; border-radius: 12px; font-weight: 700; cursor: pointer; transition: 0.3s; margin-top: 10px; }
        
        table { width: 100%; border-collapse: collapse; min-width: 900px; }
        th { text-align: left; font-size: 12px; text-transform: uppercase; color: var(--text-muted); padding: 15px; border-bottom: 2px solid #f1f5f9; white-space: nowrap; }
        td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; vertical-align: middle; }
        .action-btns { display: flex; gap: 8px; align-items: center; }
        .btn-action { text-decoration: none; font-weight: 700; font-size: 12px; padding: 8px 12px; border-radius: 8px; transition: 0.2s; text-align: center; min-width: 80px; }
        .btn-delete { background: #fee2e2; color: #991b1b; }
        .btn-activate { background: #dcfce7; color: #166534; }
        .btn-deactivate { background: #f1f5f9; color: #475569; }
        .status-badge { padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 800; text-transform: uppercase; white-space: nowrap; }
        .status-active { background: #dcfce7; color: #166534; }
        .status-offline { background: #f1f5f9; color: #64748b; }
        .alert { padding: 15px; border-radius: 12px; margin-bottom: 25px; font-weight: 600; font-size: 14px; }
        .success { background: #dcfce7; color: #166534; }
        .error { background: #fee2e2; color: #991b1b; }
        
        /* Table inline upload form */
        .inline-upload-form { display: flex; flex-direction: column; gap: 8px; align-items: flex-start; margin-top: 8px; }
        .inline-file-input { width: 170px; font-size: 11px; padding: 6px; border: 1px dashed #cbd5e1; border-radius: 6px; }
        .inline-file-input::file-selector-button { padding: 4px 8px; border-radius: 4px; font-size: 10px; margin-right: 8px; }
        .btn-upload-small { background: var(--secondary); color: white; border: none; padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer; }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>CC<span>P</span></h2>
        <nav>
            <a href="dashboard.php">Overview</a>
            <a href="manage_canteen.php" class="active">Manage Canteens</a>
            <a href="manage_admin.php">Manage Admins</a>
            <a href="reports.php">System Reports</a>
            <a href="../logout.php" style="color:#ef4444; margin-top: 50px;">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <h1>Canteen Management</h1>
        <?php echo $message; ?>

        <div class="content-card">
            <h3 style="margin-top:0">Register New Canteen</h3>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Canteen Name</label>
                    <input type="text" name="name" placeholder="E.g., Ice Berg" required pattern=".*[a-zA-Z].*" title="Must contain at least one letter">
                </div>
                
                <div class="form-group">
                    <label>Campus Location</label>
                    <input type="text" name="location" placeholder="E.g., Security Gate" required pattern=".*[a-zA-Z].*" title="Must contain at least one letter">
                </div>

                <div class="form-group">
                    <label>Cover Photo (Optional - Visible to Customers)</label>
                    <input type="file" name="canteen_image" accept="image/*">
                </div>

                <button type="submit" name="add_canteen" class="btn-add">+ Register Canteen</button>
            </form>
        </div>

        <div class="content-card">
            <h3 style="margin-top:0">Active Campus Partners</h3>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Profile Photo</th>
                        <th>Canteen Name</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $count = 1; foreach($canteens as $c): ?>
                    <tr style="<?php echo ($c['status'] == 0) ? 'background: #fcfcfc; opacity: 0.8;' : ''; ?>">
                        <td><?php echo $count++; ?></td>
                        
                        <!-- NEW COVER PHOTO COLUMN -->
                        <td style="width: 200px;">
                            <?php if (!empty($c['image']) && file_exists("../assets/images/canteens/" . $c['image'])): ?>
                                <img src="../assets/images/canteens/<?php echo htmlspecialchars($c['image']); ?>" alt="Cover" style="width: 100px; height: 60px; object-fit: cover; border-radius: 8px; border: 1px solid #e2e8f0;">
                            <?php else: ?>
                                <div style="width: 100px; height: 60px; background: #f1f5f9; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 11px; color: #94a3b8; font-weight: 700; border: 1px dashed #cbd5e1;">No Photo</div>
                            <?php endif; ?>
                            
                            <form method="POST" enctype="multipart/form-data" class="inline-upload-form">
                                <input type="hidden" name="canteen_id" value="<?php echo $c['id']; ?>">
                                <div style="display:flex; gap: 5px;">
                                    <input type="file" name="canteen_image" accept="image/*" class="inline-file-input" required>
                                    <button type="submit" name="update_image" class="btn-upload-small">Upload</button>
                                </div>
                            </form>
                        </td>

                        <td><strong><?php echo htmlspecialchars($c['name']); ?></strong></td>
                        <td>📍 <?php echo htmlspecialchars($c['location']); ?></td>
                        <td>
                            <span class="status-badge <?php echo ($c['status'] == 1) ? 'status-active' : 'status-offline'; ?>">
                                <?php echo ($c['status'] == 1) ? 'Online' : 'Offline'; ?>
                            </span>
                        </td>
                        <td>
                            <div class="action-btns">
                                <a href="manage_canteen.php?delete_id=<?php echo $c['id']; ?>" class="btn-action btn-delete" onclick="return confirm('PERMANENTLY delete this canteen?');">Delete</a>
                                <a href="manage_canteen.php?toggle_id=<?php echo $c['id']; ?>&current_status=<?php echo $c['status']; ?>" class="btn-action <?php echo ($c['status'] == 1) ? 'btn-deactivate' : 'btn-activate'; ?>">
                                    <?php echo ($c['status'] == 1) ? 'Deactivate' : 'Activate'; ?>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>