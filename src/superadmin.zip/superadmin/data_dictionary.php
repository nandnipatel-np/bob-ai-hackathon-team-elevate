<?php
session_start();
require_once '../config/db.php';
require_once '../includes/auth.php';
checkRole(['superadmin']);

$stmt = $pdo->query("SELECT * FROM data_dictionary");
$dictionary = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Data Dictionary - CCP</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2>System Data Dictionary</h2>
        <table>
            <tr>
                <th>Table Name</th>
                <th>Column Name</th>
                <th>Data Type</th>
                <th>Description</th>
            </tr>
            <?php foreach($dictionary as $row): ?>
            <tr>
                <td><?php echo $row['table_name']; ?></td>
                <td><?php echo $row['column_name']; ?></td>
                <td><?php echo $row['data_type']; ?></td>
                <td><?php echo $row['description']; ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>