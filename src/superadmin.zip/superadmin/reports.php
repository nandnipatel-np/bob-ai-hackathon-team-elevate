<?php
session_start();
require_once '../config/db.php';

// Access Control: Ensure only superadmin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login.php");
    exit();
}

// 1. Fetch Overall System Statistics
$sys_stmt = $pdo->query("
    SELECT 
        COUNT(id) as total_orders,
        COALESCE(SUM(CASE WHEN status IN ('Preparing', 'Ready', 'Completed') THEN total_amount ELSE 0 END), 0) as total_revenue
    FROM orders
");
$system_stats = $sys_stmt->fetch();

// 2. Fetch Canteen-to-Canteen Comparison (Leaderboard)
$canteen_stmt = $pdo->query("
    SELECT 
        c.name as canteen_name,
        COUNT(o.id) as total_orders,
        COALESCE(SUM(CASE WHEN o.status IN ('Preparing', 'Ready', 'Completed') THEN o.total_amount ELSE 0 END), 0) as total_revenue
    FROM canteens c
    LEFT JOIN orders o ON c.id = o.canteen_id
    GROUP BY c.id
    ORDER BY total_revenue DESC
");
$canteen_performance = $canteen_stmt->fetchAll();

// 3. Fetch Recent Platform Activity (Last 5 Orders globally)
$recent_stmt = $pdo->query("
    SELECT o.order_number, o.total_amount, o.status, c.name as canteen_name, o.order_date
    FROM orders o
    JOIN canteens c ON o.canteen_id = c.id
    ORDER BY o.order_date DESC
    LIMIT 5
");
$recent_orders = $recent_stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Reports | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Include html2pdf library for PDF generation -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
            --success: #10b981;
        }

        body { 
            margin: 0; 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: var(--bg); 
            display: flex; 
            color: var(--text-main);
        }
        
        /* Modern Sidebar */
        .sidebar { 
            width: 280px; 
            background: var(--secondary); 
            color: white; 
            height: 100vh; 
            padding: 40px 24px; 
            position: fixed; 
            box-sizing: border-box; 
        }
        .sidebar h2 { 
            font-size: 32px; 
            font-weight: 800; 
            margin-bottom: 40px; 
        }
        .sidebar h2 span { color: var(--primary); }
        .sidebar a { 
            display: flex; 
            align-items: center; 
            color: #94a3b8; 
            text-decoration: none; 
            padding: 14px 16px; 
            margin-bottom: 8px; 
            border-radius: 12px; 
            font-weight: 600;
            transition: 0.2s; 
        }
        .sidebar a:hover, .sidebar a.active { 
            background: rgba(255,255,255,0.05); 
            color: white; 
        }
        
        /* Main Content Area */
        .main-content { 
            margin-left: 280px; 
            padding: 40px 60px; 
            width: 100%; 
            box-sizing: border-box; 
        }
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 40px;
        }
        .header h1 { margin: 0; font-size: 32px; font-weight: 800; color: var(--secondary); }
        .header p { color: var(--text-muted); font-weight: 500; margin-top: 8px; }
        
        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 12px;
        }
        .btn {
            padding: 10px 20px;
            border-radius: 10px;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            border: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
        }
        .btn-primary {
            background-color: var(--primary);
            color: white;
            box-shadow: 0 4px 12px rgba(230, 126, 34, 0.2);
        }
        .btn-primary:hover { background-color: #d67118; transform: translateY(-2px); }
        .btn-secondary {
            background-color: var(--white);
            color: var(--secondary);
            border: 1px solid #e2e8f0;
        }
        .btn-secondary:hover { background-color: #f1f5f9; transform: translateY(-2px); }

        /* Stats Cards Styling */
        .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
            gap: 30px; 
            margin-bottom: 40px; 
        }
        .stat-card { 
            background: var(--white); 
            padding: 35px; 
            border-radius: 24px; 
            box-shadow: var(--shadow); 
            border: 1px solid #f1f5f9;
            transition: transform 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-5px); }
        .stat-card h3 { font-size: 42px; font-weight: 800; margin: 0; color: var(--secondary); }
        .stat-card p { 
            color: var(--text-muted); 
            margin: 8px 0 0; 
            font-weight: 700; 
            text-transform: uppercase; 
            font-size: 12px; 
            letter-spacing: 1px;
        }
        .revenue-card { border-left: 6px solid var(--success); }
        .revenue-text { color: var(--success) !important; }

        /* Performance Leaderboard and Tables */
        .content-card { 
            background: var(--white); 
            padding: 30px; 
            border-radius: 24px; 
            box-shadow: var(--shadow); 
            margin-bottom: 40px; 
            border: 1px solid #f1f5f9;
        }
        .content-card h3 { 
            margin-top: 0; 
            font-size: 20px; 
            font-weight: 800; 
            color: var(--secondary); 
            margin-bottom: 25px;
        }
        
        table { width: 100%; border-collapse: collapse; }
        th { 
            text-align: left; 
            font-size: 12px; 
            text-transform: uppercase; 
            letter-spacing: 1px; 
            color: var(--text-muted); 
            padding: 15px;
            border-bottom: 2px solid #f1f5f9;
        }
        td { padding: 20px 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
        
        /* Progress Bar Enhancements */
        .progress-bar-bg { background: #f1f5f9; border-radius: 20px; width: 100%; height: 10px; margin-top: 10px; overflow: hidden; }
        .progress-bar-fill { 
            background: linear-gradient(90deg, var(--primary), #f39c12); 
            height: 100%; 
            border-radius: 20px; 
            transition: width 1s ease-in-out;
        }
        
        /* Status Badges */
        .badge { 
            padding: 6px 14px; 
            border-radius: 10px; 
            font-size: 11px; 
            font-weight: 800; 
            background: #eff6ff; 
            color: #2563eb;
            text-transform: uppercase;
        }
        .status-pill {
            padding: 4px 10px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 700;
            background: #f1f5f9;
        }

        /* Print Media Queries */
        @media print {
            body { background-color: white !important; }
            .sidebar { display: none !important; }
            .main-content { margin-left: 0 !important; padding: 0 !important; width: 100% !important; }
            .action-buttons { display: none !important; }
            .stat-card, .content-card { 
                box-shadow: none !important; 
                border: 1px solid #e2e8f0 !important; 
                break-inside: avoid;
                margin-bottom: 20px;
            }
            .progress-bar-fill {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .stat-card:hover { transform: none; }
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>CC<span>P</span></h2>
        <nav>
            <a href="dashboard.php">Overview</a>
            <a href="manage_canteen.php">Manage Canteens</a>
            <a href="manage_admin.php">Manage Admins</a>
            <a href="reports.php" class="active">System Reports</a>
            <a href="../logout.php" style="color:#ef4444; margin-top:50px;">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="header-container">
            <div class="header">
                <h1>CCP Analytics</h1>
                <p>System-wide financial and operational performance tracking.</p>
            </div>
            
            <div class="action-buttons">
                <button onclick="window.print()" class="btn btn-secondary">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
                    Print
                </button>
                <button onclick="downloadPDF()" class="btn btn-primary">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    Download PDF
                </button>
            </div>
        </div>

        <!-- Wrapper for PDF Generation -->
        <div id="report-content">
            <div class="stats-grid">
                <div class="stat-card">
                    <h3><?php echo number_format($system_stats['total_orders']); ?></h3>
                    <p>Total Orders Processed</p>
                </div>
                <div class="stat-card revenue-card">
                    <h3 class="revenue-text">₹<?php echo number_format($system_stats['total_revenue'], 2); ?></h3>
                    <p>Gross Platform Revenue (INR)</p>
                </div>
            </div>

            <div class="content-card">
                <h3>Canteen Performance Leaderboard</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Canteen Name</th>
                            <th>Order Volume</th>
                            <th>Revenue Distribution</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $max_revenue = 0;
                        foreach($canteen_performance as $cp) {
                            if($cp['total_revenue'] > $max_revenue) $max_revenue = $cp['total_revenue'];
                        }

                        foreach($canteen_performance as $cp): 
                            $fill_percent = ($max_revenue > 0) ? ($cp['total_revenue'] / $max_revenue) * 100 : 0;
                        ?>
                        <tr>
                            <td><strong style="color: var(--secondary); font-size: 16px;"><?php echo htmlspecialchars($cp['canteen_name']); ?></strong></td>
                            <td><span class="badge"><?php echo $cp['total_orders']; ?> Orders</span></td>
                            <td style="width: 45%;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <span style="font-weight: 700;">₹<?php echo number_format($cp['total_revenue'], 2); ?></span>
                                    <span style="color: var(--text-muted); font-size: 12px; font-weight: 600;"><?php echo round($fill_percent); ?>% of Top</span>
                                </div>
                                <div class="progress-bar-bg">
                                    <div class="progress-bar-fill" style="width: <?php echo $fill_percent; ?>%;"></div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="content-card">
                <h3>Latest Platform Activity</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Partner Canteen</th>
                            <th>Amount</th>
                            <th>Current Status</th>
                            <th>Date & Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($recent_orders) > 0): ?>
                            <?php foreach($recent_orders as $ro): ?>
                            <tr>
                                <td><strong style="color: var(--secondary);">#<?php echo htmlspecialchars($ro['order_number']); ?></strong></td>
                                <td><span style="font-weight: 600;"><?php echo htmlspecialchars($ro['canteen_name']); ?></span></td>
                                <td style="font-weight: 700; color: var(--success);">₹<?php echo number_format($ro['total_amount'], 2); ?></td>
                                <td><span class="status-pill"><?php echo htmlspecialchars($ro['status']); ?></span></td>
                                <td style="color: var(--text-muted); font-size: 13px; font-weight: 600;"><?php echo date('M d, h:i A', strtotime($ro['order_date'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 40px;">No platform transactions recorded yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Script to handle PDF generation -->
    <script>
        function downloadPDF() {
            // Target the wrapper div that contains the report content
            const element = document.getElementById('report-content');
            
            // Configure html2pdf options
            const opt = {
                margin:       [0.5, 0.5, 0.5, 0.5], // top, left, bottom, right
                filename:     'CCP_Analytics_Report.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true },
                jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
            };

            // Generate and save the PDF
            html2pdf().set(opt).from(element).save();
        }
    </script>
</body>
</html>