<?php
/**
 * CCP - Manage Admins (Super Admin)
 * Location: superadmin/manage_admin.php
 */

session_start();
require_once '../config/db.php';
require_once '../mail_function.php'; // ✅ Added PHPMailer

// Super Admin Authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login.php");
    exit();
}

$message = '';

// 1. Handle Admin Update (Edit)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_admin'])) {
    $id = $_POST['admin_id'];
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $canteen_id = $_POST['canteen_id'];

    // Validation
    if (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $message = "<div class='alert error'>⚠️ Name should only contain letters and spaces.</div>";
    } elseif (!preg_match("/^[0-9]{10}$/", $phone)) {
        $message = "<div class='alert error'>⚠️ Mobile number must be exactly 10 digits.</div>";
    } else {
        $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ?, canteen_id = ? WHERE id = ? AND role = 'admin'");
        if ($stmt->execute([$name, $email, $phone, $canteen_id, $id])) {
            $message = "<div class='alert success'>✅ Admin details updated successfully!</div>";
        } else {
            $message = "<div class='alert error'>❌ Failed to update admin details.</div>";
        }
    }
}

// 2. Handle Password Reset + Email Notification
if (isset($_GET['reset_id'])) {
    $id = $_GET['reset_id'];
    $plain_password = "Charusat@123";
    $temp_password = password_hash($plain_password, PASSWORD_DEFAULT);

    // Get admin details
    $stmtUser = $pdo->prepare("
        SELECT u.name, u.email, c.name AS canteen_name
        FROM users u
        LEFT JOIN canteens c ON u.canteen_id = c.id
        WHERE u.id = ? AND u.role = 'admin'
    ");
    $stmtUser->execute([$id]);
    $adminData = $stmtUser->fetch(PDO::FETCH_ASSOC);
    
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ? AND role = 'admin'");
    if ($stmt->execute([$temp_password, $id])) {

        if ($adminData) {
            $subject = "CCP Admin Password Reset";
            $body = "
                <div style='font-family: Arial, sans-serif; border: 1px solid #e67e22; padding: 25px; border-radius: 15px; max-width: 550px; margin:auto;'>
                    <h2 style='color: #e67e22; margin-top: 0;'>Hello, {$adminData['name']} 👋</h2>
                    <p>Your <b>Campus Canteen Pre-Order (CCP)</b> admin password has been reset successfully.</p>

                    <div style='background: #f8fafc; padding: 15px; border-radius: 10px; margin: 15px 0;'>
                        <p style='margin: 8px 0;'><b>Email:</b> {$adminData['email']}</p>
                        <p style='margin: 8px 0;'><b>Assigned Canteen:</b> " . htmlspecialchars($adminData['canteen_name'] ?? 'Unassigned') . "</p>
                        <p style='margin: 8px 0;'><b>New Temporary Password:</b> {$plain_password}</p>
                    </div>

                    <p>Please login and change your password immediately for security reasons.</p>

                    <a href='http://localhost/ccp/login.php' 
                       style='display:inline-block; background:#e67e22; color:white; padding:12px 20px; text-decoration:none; border-radius:8px; font-weight:bold; margin-top:10px;'>
                        Login Now
                    </a>

                    <hr style='border:none; border-top:1px solid #eee; margin:20px 0;'>

                    <p style='font-size: 12px; color: #636e72;'>
                        Regards,<br>
                        <b>CCP System</b><br>
                        Campus Canteen Pre-Order
                    </p>
                </div>
            ";

            if (sendMail($adminData['email'], $subject, $body)) {
                $message = "<div class='alert success'>✅ Password reset successfully and email sent to admin!</div>";
            } else {
                $message = "<div class='alert success'>✅ Password reset successfully, but email could not be sent.</div>";
            }
        } else {
            $message = "<div class='alert success'>✅ Password reset successfully!</div>";
        }
    }
}

// 3. Handle Adding a new Admin + Email Notification
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_admin'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $canteen_id = $_POST['canteen_id']; 
    
    // Validation
    if (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $message = "<div class='alert error'>⚠️ Name should only contain letters and spaces.</div>";
    } elseif (!preg_match("/^[0-9]{10}$/", $phone)) {
        $message = "<div class='alert error'>⚠️ Mobile number must be exactly 10 digits.</div>";
    } else {
        $check_stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR phone = ?");
        $check_stmt->execute([$email, $phone]);
        
        if ($check_stmt->rowCount() > 0) {
            $message = "<div class='alert error'>Email or Phone already registered!</div>";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password, role, canteen_id, status) VALUES (?, ?, ?, ?, 'admin', ?, 'active')");
            
            if ($stmt->execute([$name, $email, $phone, $hashed_password, $canteen_id])) {

                // Fetch canteen name
                $canteenStmt = $pdo->prepare("SELECT name FROM canteens WHERE id = ?");
                $canteenStmt->execute([$canteen_id]);
                $canteen = $canteenStmt->fetch(PDO::FETCH_ASSOC);
                $canteen_name = $canteen ? $canteen['name'] : 'Assigned Canteen';

                $subject = "Your CCP Canteen Admin Account Has Been Created";

                $body = "
                    <div style='font-family: Arial, sans-serif; border: 1px solid #e67e22; padding: 25px; border-radius: 15px; max-width: 550px; margin:auto;'>
                        <h2 style='color: #e67e22; margin-top: 0;'>Hello, $name 👋</h2>
                        <p>Your <b>Canteen Admin Account</b> for the <b>Campus Canteen Pre-Order (CCP)</b> system has been created successfully.</p>

                        <div style='background: #f8fafc; padding: 15px; border-radius: 10px; margin: 15px 0;'>
                            <p style='margin: 8px 0;'><b>Email:</b> $email</p>
                            <p style='margin: 8px 0;'><b>Temporary Password:</b> $password</p>
                            <p style='margin: 8px 0;'><b>Assigned Canteen:</b> $canteen_name</p>
                        </div>

                        <p>Please login and change your password after first login.</p>

                        <a href='http://localhost/demo/login.php' 
                           style='display:inline-block; background:#e67e22; color:white; padding:12px 20px; text-decoration:none; border-radius:8px; font-weight:bold; margin-top:10px;'>
                            Login Now
                        </a>
                        <hr style='border:none; border-top:1px solid #eee; margin:20px 0;'>

                        <p style='font-size: 12px; color: #636e72;'>
                            Regards,<br>
                            <b>CCP System</b><br>
                            Campus Canteen Pre-Order
                        </p>
                    </div>
                ";

                if (sendMail($email, $subject, $body)) {
                    $message = "<div class='alert success'>✅ Admin account created successfully! Credentials sent to email.</div>";
                } else {
                    $message = "<div class='alert success'>✅ Admin account created successfully, but email could not be sent.</div>";
                }
            } else {
                $message = "<div class='alert error'>❌ Failed to create admin account.</div>";
            }
        }
    }
}

// 4. Handle Deleting an Admin
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'admin'");
    $stmt->execute([$id]);
    header("Location: manage_admin.php");
    exit();
}

// Fetch lists
$canteens_list = $pdo->query("SELECT id, name FROM canteens ORDER BY name ASC")->fetchAll();
$admins = $pdo->query("
    SELECT u.*, c.name as canteen_name 
    FROM users u 
    LEFT JOIN canteens c ON u.canteen_id = c.id 
    WHERE u.role = 'admin' 
    ORDER BY u.name ASC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admins | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root { --primary: #e67e22; --secondary: #1a1a1a; --bg: #f8f9fa; --white: #ffffff; }
        body { margin: 0; font-family: 'Plus Jakarta Sans', sans-serif; background-color: var(--bg); display: flex; }
        
        /* Sidebar - Matching Dashboard Style */
        .sidebar { width: 260px; background: #1a1a1a; color: white; display: flex; flex-direction: column; padding: 30px 20px; position: fixed; height: 100vh; box-sizing: border-box; }
        .sidebar .logo { font-size: 32px; font-weight: 800; margin-bottom: 5px; }
        .sidebar .logo span { color: var(--primary); }
        .sidebar .role-tag { font-size: 11px; letter-spacing: 1px; color: #888; margin-bottom: 40px; font-weight: 700; text-transform: uppercase; }
        
        .nav-menu { flex-grow: 1; }
        .nav-item { display: block; padding: 14px 20px; color: #a0a0a0; text-decoration: none; border-radius: 12px; margin-bottom: 8px; font-weight: 600; transition: 0.3s; }
        .nav-item:hover { color: white; background: rgba(255,255,255,0.05); }
        .nav-item.active { background: #333; color: white; }
        .logout { color: #ff4d4d; margin-top: auto; padding: 14px 20px; text-decoration: none; font-weight: 600; border-radius: 12px; }

        /* Main Content Area */
        .main-content { margin-left: 260px; flex-grow: 1; padding: 50px; width: calc(100% - 260px); box-sizing: border-box; }
        .header-title h1 { font-size: 32px; color: #1a1a1a; margin: 0; }
        .header-title p { color: #666; margin-top: 5px; font-weight: 500; margin-bottom: 40px; }

        .content-card { background: white; padding: 35px; border-radius: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); margin-bottom: 30px; }
        
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px; }
        input, select { width: 100%; padding: 14px; border: 1px solid #e2e8f0; border-radius: 12px; font-family: inherit; font-size: 14px; box-sizing: border-box; background: #fbfcfd; }
        
        .btn-add { background: var(--primary); color: white; border: none; padding: 14px 28px; border-radius: 12px; font-weight: 700; cursor: pointer; transition: 0.3s; }
        .btn-add:hover { background: #d35400; }
        
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 15px; color: #888; font-size: 12px; text-transform: uppercase; border-bottom: 1px solid #eee; letter-spacing: 1px; }
        td { padding: 18px 15px; border-bottom: 1px solid #eee; color: #333; font-size: 15px; }
        
        .admin-name { font-weight: 700; color: #1a1a1a; }
        .canteen-badge { background: #fff7ed; color: #c2410c; padding: 6px 12px; border-radius: 10px; font-size: 12px; font-weight: 700; }
        
        .action-group { display: flex; gap: 8px; }
        .btn-ui { text-decoration: none; font-weight: 700; font-size: 12px; padding: 8px 12px; border-radius: 8px; transition: 0.2s; cursor: pointer; border: none; }
        .btn-edit { background: #f0f2f5; color: #555; }
        .btn-reset { background: #e0f2fe; color: #0369a1; }
        .btn-delete { background: #fff0f0; color: #ff4d4d; }

        /* Modal Style */
        #editModal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; }
        .modal-box { background: white; padding: 40px; border-radius: 24px; width: 500px; box-shadow: 0 20px 50px rgba(0,0,0,0.2); }
        
        .alert { padding: 15px; border-radius: 12px; margin-bottom: 25px; font-weight: 600; }
        .success { background: #dcfce7; color: #166534; border-left: 5px solid #166534; }
        .error { background: #fff0f0; color: #ff4d4d; border-left: 5px solid #ff4d4d; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <div class="role-tag">SUPER ADMIN PANEL</div>
        
        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">Overview</a>
            <a href="manage_canteen.php" class="nav-item">Manage Canteens</a>
            <a href="manage_admin.php" class="nav-item active">Manage Admins</a>
            <a href="manage_customers.php" class="nav-item">Manage Customers</a> 
            <a href="reports.php" class="nav-item">System Reports</a>
        </nav>

        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <div class="main-content">
        <div class="header-title">
            <h1>Manage Admins</h1>
            <p>Assign and oversee administrators for individual campus canteens.</p>
        </div>
        
        <?php echo $message; ?>

        <div class="content-card">
            <h3 style="margin-top: 0; font-size: 18px; margin-bottom: 20px;">Register New Canteen Admin</h3>
            <form method="POST">
                <div class="form-grid">
                    <input type="text" name="name" placeholder="Admin Full Name" required pattern="[a-zA-Z\s]+" title="Only letters and spaces are allowed">
                    <input type="email" name="email" placeholder="Email Address" required>
                    <input type="text" name="phone" placeholder="Mobile Number (10 digits)" required pattern="[0-9]{10}" maxlength="10" title="Please enter exactly 10 digits">
                    <input type="password" name="password" placeholder="Secure Password" required>
                    
                    <select name="canteen_id" required style="grid-column: span 2;">
                        <option value="">-- Assign to a Canteen --</option>
                        <?php foreach($canteens_list as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" name="add_admin" class="btn-add">+ Create Admin Account</button>
            </form>
        </div>

        <div class="content-card">
            <h3 style="margin-top: 0; font-size: 18px; margin-bottom: 20px;">Active Administrators</h3>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Assigned Canteen</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($admins) > 0): ?>
                        <?php $count = 1; foreach($admins as $admin): ?>
                        <tr>
                            <td style="color:#aaa">#<?php echo $count++; ?></td>
                            <td class="admin-name"><?php echo htmlspecialchars($admin['name']); ?></td>
                            <td><?php echo htmlspecialchars($admin['email']); ?></td>
                            <td>
                                <span class="canteen-badge">
                                    <?php echo htmlspecialchars($admin['canteen_name'] ?? 'Unassigned'); ?>
                                </span>
                            </td>
                            <td class="action-group">
                                <button class="btn-ui btn-edit" onclick='openEdit(<?php echo json_encode($admin); ?>)'>Edit</button>
                                <a href="manage_admin.php?reset_id=<?php echo $admin['id']; ?>" 
                                   class="btn-ui btn-reset" 
                                   onclick="return confirm('Reset password for this admin to Charusat@123?');">
                                    Reset
                                </a>
                                <a href="manage_admin.php?delete=<?php echo $admin['id']; ?>" 
                                   class="btn-ui btn-delete" 
                                   onclick="return confirm('Remove this admin account permanently?');">
                                    Revoke
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: #636e72; padding: 40px;">No admin accounts found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="editModal">
        <div class="modal-box">
            <h3 style="margin-top: 0; font-size: 20px;">Edit Admin Details</h3>
            <form method="POST">
                <input type="hidden" name="admin_id" id="edit_id">
                <div style="margin-bottom: 15px;">
                    <label style="font-size: 12px; font-weight: 700; color: #64748b;">Full Name</label>
                    <input type="text" name="name" id="edit_name" required pattern="[a-zA-Z\s]+" title="Only letters and spaces are allowed">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="font-size: 12px; font-weight: 700; color: #64748b;">Email Address</label>
                    <input type="email" name="email" id="edit_email" required>
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="font-size: 12px; font-weight: 700; color: #64748b;">Phone Number</label>
                    <input type="text" name="phone" id="edit_phone" required pattern="[0-9]{10}" maxlength="10" title="Please enter exactly 10 digits">
                </div>
                <div style="margin-bottom: 25px;">
                    <label style="font-size: 12px; font-weight: 700; color: #64748b;">Assigned Canteen</label>
                    <select name="canteen_id" id="edit_canteen" required>
                        <?php foreach($canteens_list as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" name="update_admin" class="btn-add" style="width: 100%;">Save Changes</button>
                <button type="button" onclick="closeEdit()" style="background: none; border: none; color: #ef4444; width: 100%; margin-top: 15px; cursor: pointer; font-weight: 700;">Cancel</button>
            </form>
        </div>
    </div>

    <script>
        function openEdit(admin) {
            document.getElementById('edit_id').value = admin.id;
            document.getElementById('edit_name').value = admin.name;
            document.getElementById('edit_email').value = admin.email;
            document.getElementById('edit_phone').value = admin.phone;
            document.getElementById('edit_canteen').value = admin.canteen_id;
            document.getElementById('editModal').style.display = 'flex';
        }

        function closeEdit() {
            document.getElementById('editModal').style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target == document.getElementById('editModal')) {
                closeEdit();
            }
        }
    </script>

</body>
</html>