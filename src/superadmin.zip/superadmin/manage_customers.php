<?php
/**
 * CCP - Manage Customers (Super Admin)
 * Location: superadmin/manage_customers.php
 */

session_start();

// --- 1. ACCESS CONTROL ---
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../login.php?error=unauthorized");
    exit();
}

require_once '../config/db.php'; 
$message = '';

// --- 2. ACTION LOGIC ---
if (isset($_GET['action']) && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']); 

    try {
        if ($_GET['action'] === 'deactivate') {
            $pdo->prepare("UPDATE users SET status = 'inactive' WHERE id = ? AND role = 'customer'")
                ->execute([$id]);
            $message = "<div class='alert success'>Customer deactivated successfully.</div>";
        } 
        elseif ($_GET['action'] === 'activate') {
            $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ? AND role = 'customer'")
                ->execute([$id]);
            $message = "<div class='alert success'>Customer activated successfully.</div>";
        }
        elseif ($_GET['action'] === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'customer'");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $message = "<div class='alert success'>Customer deleted permanently.</div>";
            } else {
                $message = "<div class='alert error'>Customer could not be deleted.</div>";
            }
        }
    } catch (PDOException $e) {
        $message = "<div class='alert error'>Error: This customer may be linked to order history and cannot be deleted.</div>";
    }
}

// --- 3. SEARCH & FETCH DATA ---
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$queryStr = "SELECT id, customer_id, name, email, status FROM users WHERE role = 'customer'";

if ($search !== '') {
    $queryStr .= " AND (customer_id LIKE :search1 OR name LIKE :search2 OR email LIKE :search3)";
}
$queryStr .= " ORDER BY id DESC";

$stmt = $pdo->prepare($queryStr);

if ($search !== '') {
    $searchTerm = "%$search%";
    $stmt->execute([
        'search1' => $searchTerm,
        'search2' => $searchTerm,
        'search3' => $searchTerm
    ]);
} else {
    $stmt->execute();
}
$customers = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Customers | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f8f9fa; margin: 0; display: flex; min-height: 100vh; }
        
        .sidebar { width: 260px; background: #1a1a1a; color: white; display: flex; flex-direction: column; padding: 30px 20px; position: fixed; height: 100vh; box-sizing: border-box; }
        .sidebar .logo { font-size: 32px; font-weight: 800; margin-bottom: 5px; }
        .sidebar .logo span { color: #e67e22; }
        .sidebar .role-tag { font-size: 11px; letter-spacing: 1px; color: #888; margin-bottom: 40px; font-weight: 700; text-transform: uppercase; }
        
        .nav-menu { flex-grow: 1; }
        .nav-item { display: block; padding: 14px 20px; color: #a0a0a0; text-decoration: none; border-radius: 12px; margin-bottom: 8px; font-weight: 600; transition: 0.3s; }
        .nav-item:hover { color: white; background: rgba(255,255,255,0.05); }
        .nav-item.active { background: #333; color: white; }
        
        .logout { color: #ff4d4d; margin-top: auto; padding: 14px 20px; text-decoration: none; font-weight: 600; border-radius: 12px; }
        .logout:hover { background: rgba(255,77,77,0.1); }

        .main-content { margin-left: 260px; flex-grow: 1; padding: 50px; width: calc(100% - 260px); box-sizing: border-box; }
        .header-flex { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; }
        .header-title h1 { font-size: 32px; color: #1a1a1a; margin: 0; }
        .header-title p { color: #666; margin-top: 5px; font-weight: 500; }

        .search-box input {
            padding: 12px 20px; border-radius: 12px; border: 1px solid #ddd; width: 300px; font-family: inherit; font-size: 14px; outline: none;
        }
        .search-box input:focus { border-color: #e67e22; }

        .card { background: white; padding: 35px; border-radius: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); }

        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 15px; color: #888; font-size: 12px; text-transform: uppercase; border-bottom: 1px solid #eee; letter-spacing: 1px; }
        td { padding: 18px 15px; border-bottom: 1px solid #eee; color: #333; font-size: 15px; }

        .badge { padding: 6px 12px; border-radius: 8px; font-size: 11px; font-weight: 800; text-transform: uppercase; }
        .status-active { background: #e6f9ed; color: #1fb45a; }
        .status-inactive { background: #fff0f0; color: #ff4d4d; }

        .btn { padding: 8px 14px; border-radius: 8px; text-decoration: none; font-size: 13px; font-weight: 700; transition: 0.2s; display: inline-block; }
        .btn-edit { background: #f0f2f5; color: #555; margin-right: 5px; }
        .btn-edit:hover { background: #e2e6ea; }
        .btn-delete { color: #ff4d4d; }
        .btn-delete:hover { text-decoration: underline; }

        .alert { padding: 15px; border-radius: 12px; margin-bottom: 25px; font-weight: 600; }
        .success { background: #dcfce7; color: #166534; border-left: 5px solid #166534; }
        .error { background: #fff0f0; color: #ff4d4d; border-left: 5px solid #ff4d4d; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <div class="role-tag">SUPER ADMIN PANEL</div>
        
        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">Overview</a>
            <a href="manage_canteen.php" class="nav-item">Manage Canteens</a>
            <a href="manage_admin.php" class="nav-item">Manage Admins</a>
            <a href="manage_customers.php" class="nav-item active">Manage Customers</a> 
            <a href="reports.php" class="nav-item">System Reports</a>
        </nav>

        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <div class="main-content">
        <div class="header-flex">
            <div class="header-title">
                <h1>Customer Management</h1>
                <p>View and manage all registered users in the CCP platform.</p>
            </div>
            <div class="search-box">
                <form method="GET">
                    <input type="text" name="search" placeholder="Search by Customer ID, name or email..." value="<?php echo htmlspecialchars($search); ?>">
                </form>
            </div>
        </div>

        <?php if($message) echo $message; ?>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>Customer ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($customers) > 0): ?>
                        <?php foreach ($customers as $user): ?>
                        <tr>
                            <td style="color:#aaa"><?php echo htmlspecialchars($user['customer_id']); ?></td>
                            <td style="font-weight:700"><?php echo htmlspecialchars($user['name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <span class="badge <?php echo ($user['status'] == 'active') ? 'status-active' : 'status-inactive'; ?>">
                                    <?php echo htmlspecialchars($user['status']); ?>
                                </span>
                            </td>
                            <td>
                                <?php if($user['status'] == 'active'): ?>
                                    <a href="?action=deactivate&id=<?php echo $user['id']; ?>" class="btn btn-edit">Deactivate</a>
                                <?php else: ?>
                                    <a href="?action=activate&id=<?php echo $user['id']; ?>" class="btn btn-edit" style="color:#1fb45a">Activate</a>
                                <?php endif; ?>
                                <a href="?action=delete&id=<?php echo $user['id']; ?>" class="btn btn-delete" onclick="return confirm('Delete customer permanently?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align:center; padding: 40px; color: #999;">No customers found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>