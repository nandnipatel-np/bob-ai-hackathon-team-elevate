<?php
session_start();
require_once '../config/db.php';

// Check if user has an active session
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Verify user still exists and is active
$user_check_stmt = $pdo->prepare("SELECT status, name FROM users WHERE id = ?");
$user_check_stmt->execute([$user_id]);
$current_user = $user_check_stmt->fetch();

// If user doesn't exist or is inactive
if (!$current_user || $current_user['status'] !== 'active') {
    session_unset();
    session_destroy();
    header("Location: ../login.php?error=account_disabled");
    exit();
}

// Use latest name from DB instead of session
$user_name = $current_user['name'];

// Fetch recent orders
$stmt = $pdo->prepare("
    SELECT o.*, c.name AS canteen_name 
    FROM orders o 
    JOIN canteens c ON o.canteen_id = c.id 
    WHERE o.user_id = ? 
    ORDER BY o.order_date DESC 
    LIMIT 5
");
$stmt->execute([$user_id]);
$recent_orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --primary-light: #fdf2e9;
            --secondary: #1a1a1a;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --bg: #f8fafc;
            --white: #ffffff;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            color: var(--text-main);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            color: white;
            padding: 40px 24px;
            position: fixed;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
        }

        .logo {
            font-size: 32px;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 40px;
        }

        .logo span {
            color: var(--primary);
        }

        .nav-item {
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 8px;
            transition: 0.2s;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
        }

        .nav-item:hover,
        .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .main-content {
            margin-left: 280px;
            padding: 40px 60px;
            width: calc(100% - 280px);
            box-sizing: border-box;
        }

        .hero-section {
            background: linear-gradient(135deg, var(--secondary), #333);
            padding: 60px;
            border-radius: 24px;
            color: white;
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
        }

        .hero-section h1 {
            font-size: 32px;
            margin: 0 0 10px 0;
            font-weight: 800;
        }

        .hero-section p {
            color: #cbd5e1;
            margin-bottom: 30px;
            font-weight: 500;
        }

        .search-glass {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 8px;
            border-radius: 16px;
            display: flex;
            gap: 10px;
            max-width: 600px;
            border: 1px solid rgba(255,255,255,0.1);
        }

        .search-glass input {
            flex: 1;
            background: transparent;
            border: none;
            padding: 12px 20px;
            color: white;
            font-size: 16px;
            outline: none;
        }

        .search-glass input::placeholder {
            color: #94a3b8;
        }

        .search-glass button {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0 30px;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
        }

        .search-glass button:hover {
            background: #d35400;
        }

        .section-card {
            background: var(--white);
            padding: 30px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            border: 1px solid #f1f5f9;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px;
            color: var(--text-muted);
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        td {
            padding: 20px 15px;
            border-top: 1px solid #f1f5f9;
            font-size: 14px;
        }

        .status-pill {
            padding: 6px 14px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            display: inline-block;
        }

        .status-completed {
            background: #ecfdf5;
            color: #10b981;
        }

        .status-pending {
            background: #fffbeb;
            color: #f59e0b;
        }

        .status-preparing {
            background: #eff6ff;
            color: #3b82f6;
        }

        .status-ready {
            background: #f3e8ff;
            color: #9333ea;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <nav>
            <a href="dashboard.php" class="nav-item active">Dashboard</a>
            <a href="canteens.php" class="nav-item">Order Food</a>
            <a href="orders.php" class="nav-item">My Orders</a>
            <a href="profile.php" class="nav-item">Profile</a>
            <a href="../logout.php" class="nav-item" style="margin-top: auto; color: #ef4444;">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="hero-section">
            <h1>Hey, <?= htmlspecialchars(explode(' ', $user_name)[0]); ?>! 👋</h1>
            <p>Welcome to CCP. Order fresh meals from your favorite campus canteens.</p>

            <form action="search_results.php" method="GET" class="search-glass">
                <input type="text" name="query" placeholder="Search Maggi, Cold Coffee, Thali..." required>
                <button type="submit">Search</button>
            </form>
        </div>

        <div class="section-card">
            <h3 style="margin-top:0; margin-bottom: 25px; font-weight: 800;">Recent Platform Activity</h3>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Canteen</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($recent_orders) > 0): ?>
                        <?php foreach ($recent_orders as $order): ?>
                        <tr>
                            <td><strong>#<?= htmlspecialchars($order['order_number']); ?></strong></td>
                            <td><?= htmlspecialchars($order['canteen_name']); ?></td>
                            <td style="font-weight: 700;">₹<?= number_format($order['total_amount'], 2); ?></td>
                            <td>
                                <span class="status-pill status-<?= strtolower($order['status']); ?>">
                                    <?= htmlspecialchars($order['status']); ?>
                                </span>
                            </td>
                            <td style="color: var(--text-muted); font-weight: 500;"><?= date('d M, Y', strtotime($order['order_date'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 40px;">No recent orders found. Start ordering now!</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>