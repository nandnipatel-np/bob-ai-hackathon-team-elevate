<?php
session_start();
require_once '../config/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);

    if (empty($name)) {
        $message = "<div class='alert error'>❌ Name cannot be empty.</div>";
    } elseif (!empty($phone) && !preg_match('/^[0-9]{10}$/', $phone)) {
        $message = "<div class='alert error'>❌ Enter valid 10-digit phone number.</div>";
    } else {
        $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?");
        if ($stmt->execute([$name, $phone, $user_id])) {
            $_SESSION['name'] = $name; // Update session name
            $message = "<div class='alert success'>✅ Profile updated successfully!</div>";
        } else {
            $message = "<div class='alert error'>❌ Failed to update profile.</div>";
        }
    }
}

// Fetch Current Details
$stmt = $pdo->prepare("SELECT customer_id, name, email, phone FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            color: var(--text-main);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            color: white;
            padding: 40px 24px;
            position: fixed;
            box-sizing: border-box;
        }

        .logo {
            font-size: 32px;
            font-weight: 800;
            color: white;
            margin-bottom: 40px;
            text-decoration: none;
            display: block;
        }

        .logo span {
            color: var(--primary);
        }

        .nav-item {
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
            transition: 0.2s;
        }

        .nav-item:hover,
        .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .main-content {
            margin-left: 280px;
            padding: 40px 60px;
            width: calc(100% - 280px);
            box-sizing: border-box;
        }

        .edit-card {
            max-width: 600px;
            background: var(--white);
            padding: 40px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            border: 1px solid #f1f5f9;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text-main);
            font-size: 14px;
        }

        input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            font-family: inherit;
            font-size: 15px;
            box-sizing: border-box;
            outline: none;
            transition: 0.2s;
        }

        input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(230, 126, 34, 0.1);
        }

        input[disabled] {
            background: #f8fafc;
            color: var(--text-muted);
            cursor: not-allowed;
            border-style: dashed;
        }

        .btn-save {
            background: var(--primary);
            color: white;
            border: none;
            padding: 14px 30px;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            transition: 0.3s;
        }

        .btn-save:hover {
            background: #d35400;
            transform: translateY(-2px);
            box-shadow: 0 8px 15px rgba(230, 126, 34, 0.2);
        }

        .alert {
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-weight: 600;
        }

        .success {
            background: #ecfdf5;
            color: #10b981;
        }

        .error {
            background: #fef2f2;
            color: #ef4444;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <a href="dashboard.php" class="logo">CC<span>P</span></a>
        <nav>
            <a href="dashboard.php" class="nav-item">Dashboard</a>
            <a href="canteens.php" class="nav-item">Order Food</a>
            <a href="orders.php" class="nav-item">My Orders</a>
            <a href="profile.php" class="nav-item active">Profile</a>
            <a href="../logout.php" class="nav-item" style="margin-top: 50px; color: #ef4444;">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <h1 style="margin-top: 0; margin-bottom: 30px; font-weight: 800;">Edit Profile</h1>

        <div class="edit-card">
            <?php echo $message; ?>

            <form method="POST">

                <div class="form-group">
                    <label>Customer ID</label>
                    <input type="text" value="<?php echo htmlspecialchars($user['customer_id']); ?>" disabled>
                </div>

                <div class="form-group">
                    <label>Email Address (Immutable)</label>
                    <input type="text" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                </div>

                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                </div>

                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" placeholder="Enter 10-digit mobile number">
                </div>

                <button type="submit" class="btn-save">Save Changes</button>
                <a href="profile.php" style="display:block; text-align:center; margin-top:15px; color:var(--text-muted); text-decoration:none; font-size:14px; font-weight: 600;">Cancel</a>
            </form>
        </div>
    </div>

</body>
</html>