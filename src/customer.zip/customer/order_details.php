<?php
session_start();
require_once '../config/db.php';

// Security check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit();
}

// Validate order ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: orders.php");
    exit();
}

$order_id = (int) $_GET['id'];
$user_id = $_SESSION['user_id'];

// Fetch order info
$stmt = $pdo->prepare("
    SELECT o.*, c.name AS canteen_name, u.name AS customer_name 
    FROM orders o
    JOIN canteens c ON o.canteen_id = c.id
    JOIN users u ON o.user_id = u.id
    WHERE o.id = ? AND o.user_id = ?
");
$stmt->execute([$order_id, $user_id]);
$order_info = $stmt->fetch();

if (!$order_info) {
    header("Location: orders.php?error=notfound");
    exit();
}

// Fetch ordered items
$stmt = $pdo->prepare("
    SELECT od.*, m.name AS item_name 
    FROM order_details od
    JOIN menu_items m ON od.item_id = m.id
    WHERE od.order_id = ?
");
$stmt->execute([$order_id]);
$items = $stmt->fetchAll();

// Safe order date fallback
$date_col = $order_info['order_date'] ?? $order_info['created_at'] ?? date('Y-m-d H:i:s');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt #<?= htmlspecialchars($order_info['order_number']); ?> | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
        }

        * { box-sizing: border-box; }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            color: var(--text-main);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            color: white;
            padding: 40px 24px;
            position: fixed;
            box-sizing: border-box;
        }

        .logo {
            font-size: 32px;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 40px;
            text-decoration: none;
            display: block;
        }

        .logo span { color: var(--primary); }

        .nav-item {
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
            transition: 0.2s;
        }

        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .main-content {
            margin-left: 280px;
            padding: 40px 60px;
            width: 100%;
            box-sizing: border-box;
        }

        .receipt-card {
            max-width: 600px;
            background: var(--white);
            border-radius: 24px;
            box-shadow: var(--shadow);
            border: 1px solid #f1f5f9;
            overflow: hidden;
            margin: 0 auto;
        }

        .receipt-header {
            background: var(--secondary);
            color: white;
            padding: 40px;
            text-align: center;
        }

        .status-badge {
            background: var(--primary);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            margin-top: 15px;
            display: inline-block;
        }

        .receipt-details { padding: 25px 30px 10px; }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            background: #f8fafc;
            padding: 16px;
            border-radius: 14px;
            border: 1px solid #e2e8f0;
            margin-top: 15px;
        }

        .info-col { display: flex; flex-direction: column; gap: 4px; }
        .info-col:last-child { text-align: right; }

        .info-label {
            font-size: 11px;
            font-weight: 800;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .info-value { font-size: 14px; font-weight: 700; color: var(--secondary); }

        .item-table {
            width: 100%;
            padding: 0 30px 30px;
            border-collapse: collapse;
            display: block;
        }

        .item-table tbody { display: table; width: 100%; }

        .item-table td {
            padding: 15px 30px;
            border-bottom: 1px solid #f1f5f9;
        }

        .item-name { font-weight: 600; font-size: 15px; }
        .item-qty { color: var(--text-muted); font-size: 13px; }

        .receipt-footer {
            padding: 30px;
            background: #fafafa;
            border-top: 2px dashed #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* Updated Buttons Styling */
        .button-container {
            padding: 0 30px 30px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-top: 20px;
        }

        .btn-action {
            width: 100%;
            padding: 15px 20px;
            border-radius: 12px;
            border: none;
            cursor: pointer;
            font-weight: 700;
            font-size: 15px;
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-download {
            background: #27ae60;
            color: white;
        }

        .btn-download:hover {
            background: #219150;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(39, 174, 96, 0.2);
        }

        .btn-print {
            background: var(--secondary);
            color: white;
        }

        .btn-print:hover {
            background: #000000;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        @media print {
            .sidebar, .button-container, .back-link { display: none !important; }
            .main-content { margin: 0; padding: 0; }
            .receipt-card { box-shadow: none; border: none; width: 100%; max-width: 100%; }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <a href="dashboard.php" class="logo">CC<span>P</span></a>
        <nav>
            <a href="dashboard.php" class="nav-item">Dashboard</a>
            <a href="canteens.php" class="nav-item">Order Food</a>
            <a href="orders.php" class="nav-item active">My Orders</a>
            <a href="profile.php" class="nav-item">Profile</a>
        </nav>
    </div>

    <div class="main-content">
        <a href="orders.php" class="back-link" style="text-decoration: none; color: var(--primary); font-weight: 700;">← Back to My Orders</a>

        <div id="receipt-content" class="receipt-card" style="margin-top: 30px;">
            <div class="receipt-header">
                <div style="font-size: 14px; opacity: 0.7;">Digital Receipt</div>
                <h2 style="margin: 5px 0;">Order #<?= htmlspecialchars($order_info['order_number']); ?></h2>
                <div class="status-badge"><?= htmlspecialchars($order_info['status']); ?></div>
            </div>

            <div class="receipt-details">
                <div style="font-weight: 800; color: var(--text-muted); font-size: 12px; letter-spacing: 1px;">
                    PARTNER: <?= strtoupper(htmlspecialchars($order_info['canteen_name'])); ?>
                </div>

                <div class="info-grid">
                    <div class="info-col">
                        <span class="info-label">Customer Name</span>
                        <span class="info-value"><?= htmlspecialchars($order_info['customer_name'] ?? 'Guest'); ?></span>
                    </div>
                    <div class="info-col">
                        <span class="info-label">Order Date & Time</span>
                        <span class="info-value"><?= date('d M Y, h:i A', strtotime($date_col)); ?></span>
                    </div>
                </div>
            </div>

            <table class="item-table">
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td>
                            <div class="item-name"><?= htmlspecialchars($item['item_name']); ?></div>
                            <div class="item-qty">Quantity: <?= $item['quantity']; ?></div>
                        </td>
                        <td align="right" style="font-weight: 800; font-size: 15px; color: var(--secondary);">
                            ₹<?= number_format($item['subtotal'], 2); ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="receipt-footer">
                <span style="font-weight: 700; color: var(--text-muted); font-size: 13px; letter-spacing: 1px;">TOTAL PAID</span>
                <span style="font-size: 26px; font-weight: 800; color: var(--primary);">₹<?= number_format($order_info['total_amount'], 2); ?></span>
            </div>

            <div class="button-container">
                <button class="btn-action btn-download" onclick="downloadReceipt()">
                    Download Receipt (PDF)
                </button>
                <button class="btn-action btn-print" onclick="window.print()">
                    Print Receipt
                </button>
            </div>
        </div>
    </div>

    <script>
        function downloadReceipt() {
            // Target the receipt card
            const element = document.getElementById('receipt-content');
            
            // Hide buttons inside the card before capturing
            const buttons = document.querySelector('.button-container');
            buttons.style.display = 'none';

            // PDF Options
            const opt = {
                margin:       0.5,
                filename:     'Receipt_<?= $order_info['order_number']; ?>.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true },
                jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
            };

            // Generate PDF
            html2pdf().set(opt).from(element).save().then(() => {
                // Restore buttons after download
                buttons.style.display = 'flex';
            });
        }
    </script>
</body>
</html>