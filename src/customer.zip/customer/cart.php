<?php
session_start();
require_once '../config/db.php';

// Security: only logged-in customers can access cart
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php?msg=login_required");
    exit();
}

// Set timezone to India
date_default_timezone_set('Asia/Kolkata');

// Minimum pickup time = 20 minutes from now
$min_datetime = date('Y-m-d\TH:i', strtotime('+20 minutes'));

// 1. ADD TO CART LOGIC
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $item_id = (int) $_POST['item_id'];
    $quantity = max(1, (int) $_POST['quantity']);
    $canteen_id = (int) $_POST['canteen_id'];

    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Prevent mixing items from different canteens
    if (isset($_SESSION['checkout_canteen_id']) && $_SESSION['checkout_canteen_id'] != $canteen_id) {
        $_SESSION['cart'] = [];
    }

    // Add item quantity
    if (isset($_SESSION['cart'][$item_id])) {
        $_SESSION['cart'][$item_id] += $quantity;
    } else {
        $_SESSION['cart'][$item_id] = $quantity;
    }

    // Set checkout canteen context
    $_SESSION['checkout_canteen_id'] = $canteen_id;

    header("Location: menu.php?canteen_id=$canteen_id&success=1");
    exit();
}

// 2. REMOVE ITEM
if (isset($_GET['remove']) && is_numeric($_GET['remove'])) {
    $remove_id = (int) $_GET['remove'];
    if (isset($_SESSION['cart'][$remove_id])) {
        unset($_SESSION['cart'][$remove_id]);
    }

    // If cart becomes empty, remove canteen context too
    if (empty($_SESSION['cart'])) {
        unset($_SESSION['checkout_canteen_id']);
    }

    header("Location: cart.php");
    exit();
}

// 3. CLEAR CART
if (isset($_GET['clear']) && $_GET['clear'] == 1) {
    unset($_SESSION['cart']);
    unset($_SESSION['checkout_canteen_id']);
    unset($_SESSION['checkout_pickup_time']);
    unset($_SESSION['checkout_total']);
    unset($_SESSION['pending_order_number']);
    header("Location: cart.php");
    exit();
}

$error_msg = "";

// 4. PROCEED TO PAYMENT
if (isset($_POST['proceed_to_payment'])) {
    if (!empty($_SESSION['cart'])) {

        $pickup_input = trim($_POST['pickup_time'] ?? '');

        if (empty($pickup_input)) {
            $error_msg = "Please select pickup time.";
        } else {
            // Parse datetime-local input safely
            $pickup_dt = DateTime::createFromFormat('Y-m-d\TH:i', $pickup_input);

            if (!$pickup_dt) {
                $error_msg = "Invalid pickup time format.";
            } else {
                // Current time
                $now = new DateTime();

                // Round current time to next full minute to avoid seconds mismatch
                $now->setTime((int)$now->format('H'), (int)$now->format('i'), 0);

                // Minimum allowed = 20 mins from now
                $minimum_dt = clone $now;
                $minimum_dt->modify('+20 minutes');

                if ($pickup_dt < $minimum_dt) {
                    $error_msg = "Pickup time must be at least 20 minutes from now.";
                } else {
                    $_SESSION['checkout_pickup_time'] = $pickup_dt->format('Y-m-d H:i:s');
                    $_SESSION['checkout_total'] = (float) $_POST['total_amount'];
                    $_SESSION['pending_order_number'] = 'CCP' . strtoupper(substr(uniqid(), 7));
                    header("Location: payment.php");
                    exit();
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            display: flex;
            color: var(--text-main);
        }

        .sidebar {
            width: 280px;
            background: var(--secondary);
            color: white;
            height: 100vh;
            padding: 40px 24px;
            position: fixed;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
        }

        .sidebar h2 {
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 40px;
            margin-top: 0;
        }

        .sidebar h2 span { color: var(--primary); }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            margin-bottom: 8px;
            border-radius: 12px;
            font-weight: 600;
            transition: 0.2s;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .logout-link {
            margin-top: auto;
            color: #ef4444 !important;
        }

        .main-content {
            margin-left: 280px;
            padding: 60px;
            width: 100%;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            min-height: 100vh;
        }

        .cart-card {
            background: var(--white);
            padding: 40px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 900px;
            border: 1px solid #f1f5f9;
            height: fit-content;
        }

        .cart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 35px;
        }

        .cart-header h2 {
            margin: 0;
            font-weight: 800;
            font-size: 28px;
        }

        .btn-clear {
            font-size: 13px;
            font-weight: 700;
            color: #ef4444;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 12px;
            background: #fff1f2;
            transition: 0.2s;
        }

        .btn-clear:hover {
            background: #ef4444;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        th {
            text-align: left;
            padding: 15px;
            color: var(--text-muted);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid #f8fafc;
        }

        td {
            padding: 20px 15px;
            border-bottom: 1px solid #f8fafc;
            font-size: 15px;
        }

        .total-section {
            background: #f8fafc;
            padding: 35px;
            border-radius: 24px;
            border: 1px solid #e2e8f0;
            margin-top: 20px;
        }

        .total-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .total-label {
            font-size: 26px;
            font-weight: 800;
        }

        .total-price {
            font-size: 32px;
            font-weight: 800;
            color: var(--primary);
        }

        .time-label {
            display: block;
            margin-bottom: 10px;
            font-weight: 700;
            color: var(--text-muted);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        input[type="datetime-local"] {
            width: 100%;
            padding: 16px;
            border: 1.5px solid #e2e8f0;
            border-radius: 14px;
            font-family: inherit;
            font-size: 16px;
            margin-bottom: 25px;
            outline: none;
            box-sizing: border-box;
        }

        .btn-pay {
            width: 100%;
            background: var(--primary);
            color: white;
            border: none;
            padding: 20px;
            border-radius: 16px;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-pay:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(230, 126, 34, 0.2);
        }

        .empty-cart {
            text-align: center;
            padding: 60px 0;
            color: var(--text-muted);
        }

        .alert-error {
            background: #fef2f2;
            color: #991b1b;
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 600;
            border: 1px solid #fee2e2;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>CC<span>P</span></h2>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="canteens.php">Order Food</a>
            <a href="cart.php" class="active">View Cart</a>
            <a href="orders.php">My Orders</a>
            <a href="profile.php">Profile</a>
            <a href="../logout.php" class="logout-link">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="cart-card">
            <?php if (!empty($error_msg)): ?>
                <div class="alert-error"><?= htmlspecialchars($error_msg) ?></div>
            <?php endif; ?>

            <?php if (!empty($_SESSION['cart'])): ?>
                <div class="cart-header">
                    <h2>Review Your Cart</h2>
                    <a href="cart.php?clear=1" class="btn-clear" onclick="return confirm('Empty your cart?')">Clear Cart</a>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Menu Item</th>
                            <th>Price</th>
                            <th>Qty</th>
                            <th>Subtotal</th>
                            <th style="text-align: right;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total = 0;
                        foreach ($_SESSION['cart'] as $id => $qty):
                            $stmt = $pdo->prepare("SELECT name, price FROM menu_items WHERE id = ?");
                            $stmt->execute([$id]);
                            $item = $stmt->fetch();

                            if ($item):
                                $subtotal = $item['price'] * $qty;
                                $total += $subtotal;
                        ?>
                        <tr>
                            <td><strong style="color: var(--secondary);"><?= htmlspecialchars($item['name']); ?></strong></td>
                            <td>₹<?= number_format($item['price'], 2); ?></td>
                            <td style="font-weight: 800; color: var(--primary);"><?= $qty; ?></td>
                            <td style="font-weight: 800;">₹<?= number_format($subtotal, 2); ?></td>
                            <td style="text-align: right;">
                                <a href="cart.php?remove=<?= $id; ?>" style="color:#ef4444; text-decoration:none; font-weight:700; font-size:13px;">Remove</a>
                            </td>
                        </tr>
                        <?php 
                            endif;
                        endforeach;
                        ?>
                    </tbody>
                </table>

                <div class="total-section">
                    <div class="total-row">
                        <span class="total-label">Total to Pay:</span>
                        <span class="total-price">₹<?= number_format($total, 2); ?></span>
                    </div>

                    <form method="POST">
                        <input type="hidden" name="total_amount" value="<?= $total; ?>">

                        <label class="time-label">Schedule Pickup Date & Time</label>
                        <input 
                            type="datetime-local" 
                            id="pickup_time" 
                            name="pickup_time" 
                            min="<?= $min_datetime; ?>" 
                            value="<?= $min_datetime; ?>" 
                            required
                        >
                        <p style="font-size: 12px; color: #888; margin-top: -15px; margin-bottom: 20px;">
                            * Orders require at least 20 minutes to prepare.
                        </p>

                        <button type="submit" name="proceed_to_payment" class="btn-pay">Confirm & Proceed to Pay</button>
                    </form>
                </div>
            <?php else: ?>
                <div class="empty-cart">
                    <h3 style="font-size: 24px; margin-bottom: 10px;">Your cart is feeling light</h3>
                    <p>Add some delicious meals from your favorite canteen to get started.</p>
                    <a href="canteens.php" style="color:var(--primary); font-weight:700; text-decoration:none; display:inline-block; margin-top:20px;">Browse Canteens →</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const timeInput = document.getElementById("pickup_time");
        if (timeInput) {
            timeInput.addEventListener("change", function() {
                if (this.value < this.min) {
                    alert("Please allow at least 20 minutes for preparation. The earliest available time is automatically selected.");
                    this.value = this.min;
                }
            });
        }
    });
    </script>
</body>
</html>