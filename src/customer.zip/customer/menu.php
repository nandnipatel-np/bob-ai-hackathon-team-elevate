<?php
session_start();
require_once '../config/db.php';

// Check if canteen_id is provided
if (!isset($_GET['canteen_id']) || !is_numeric($_GET['canteen_id'])) {
    header("Location: canteens.php");
    exit();
}

$canteen_id = (int) $_GET['canteen_id'];

// Fetch Canteen details and check if active
$stmt = $pdo->prepare("SELECT * FROM canteens WHERE id = ?");
$stmt->execute([$canteen_id]);
$canteen = $stmt->fetch();

// Redirect if canteen not found or offline
if (!$canteen || $canteen['status'] == 0) {
    header("Location: canteens.php?error=offline");
    exit();
}

// Fetch only available items
$stmt = $pdo->prepare("SELECT * FROM menu_items WHERE canteen_id = ? AND availability > 0 ORDER BY id DESC");
$stmt->execute([$canteen_id]);
$menu_items = $stmt->fetchAll();

// Calculate cart count
$cart_count = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    $cart_count = array_sum($_SESSION['cart']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - <?= htmlspecialchars($canteen['name']); ?> | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --primary-dark: #d35400;
            --secondary: #1a1a1a;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --bg: #f8fafc;
            --white: #ffffff;
            --sidebar-width: 280px;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            color: var(--text-main);
        }

        .sidebar {
            width: var(--sidebar-width);
            background: var(--secondary);
            color: white;
            height: 100vh;
            padding: 40px 24px;
            position: fixed;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            z-index: 100;
        }

        .sidebar h2 {
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 40px;
            margin-top: 0;
        }

        .sidebar h2 span {
            color: var(--primary);
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            margin-bottom: 8px;
            border-radius: 12px;
            font-weight: 600;
            transition: 0.2s;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .logout-link {
            margin-top: auto;
            color: #ef4444 !important;
        }

        .login-link {
            margin-top: auto;
            color: var(--primary) !important;
        }

        .main-content {
            margin-left: var(--sidebar-width);
            padding: 40px 60px;
            width: calc(100% - var(--sidebar-width));
            box-sizing: border-box;
        }

        .header-card {
            background: linear-gradient(135deg, var(--secondary), #333);
            padding: 50px;
            border-radius: 24px;
            color: white;
            margin-bottom: 40px;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }

        .header-card h1 {
            margin: 0;
            font-size: 32px;
            font-weight: 800;
        }

        .header-card p {
            margin: 10px 0 0;
            color: #cbd5e1;
            font-size: 16px;
        }

        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
        }

        .food-card {
            background: var(--white);
            border-radius: 24px;
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid #f1f5f9;
            transition: 0.3s;
            display: flex;
            flex-direction: column;
        }

        .food-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.06);
        }

        .image-wrapper {
            height: 200px;
            overflow: hidden;
        }

        .food-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: 0.5s;
        }

        .food-card:hover .food-img {
            transform: scale(1.1);
        }

        .card-body {
            padding: 25px;
            flex-grow: 1;
        }

        .category-badge {
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--primary);
            background: #fff4e6;
            padding: 5px 12px;
            border-radius: 10px;
            display: inline-block;
            margin-bottom: 12px;
        }

        .food-card h3 {
            margin: 0 0 10px 0;
            font-size: 20px;
            font-weight: 700;
            color: var(--secondary);
        }

        .price {
            font-size: 24px;
            font-weight: 800;
            color: var(--secondary);
            margin-bottom: 20px;
        }

        .add-to-cart-form {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .qty-input {
            width: 55px;
            height: 45px;
            border: 2px solid #f1f5f9;
            border-radius: 12px;
            text-align: center;
            font-family: inherit;
            font-weight: 700;
            outline: none;
        }

        .btn-add {
            flex-grow: 1;
            height: 45px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-add:hover {
            background: var(--primary-dark);
        }

        .floating-cart {
            position: fixed;
            bottom: 35px;
            right: 35px;
            background: var(--secondary);
            color: white;
            padding: 18px 30px;
            border-radius: 20px;
            text-decoration: none;
            font-weight: 700;
            box-shadow: 0 15px 35px rgba(0,0,0,0.25);
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 1000;
            transition: 0.3s;
        }

        .floating-cart:hover {
            transform: scale(1.05) translateY(-5px);
        }

        .cart-badge {
            background: var(--primary);
            color: white;
            padding: 4px 10px;
            border-radius: 10px;
            font-size: 13px;
        }

        .alert-success {
            background: #ecfdf5;
            color: #059669;
            padding: 20px;
            border-radius: 16px;
            margin-bottom: 30px;
            font-weight: 600;
            border-left: 5px solid #10b981;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>CC<span>P</span></h2>
        <nav>
            <a href="../index.php">Home</a>
            <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'customer'): ?>
                <a href="dashboard.php">Dashboard</a>
                <a href="canteens.php" class="active">Order Food</a>
                <a href="cart.php">View Cart</a>
                <a href="orders.php">My Orders</a>
                <a href="profile.php">Profile</a>
                <a href="../logout.php" class="logout-link">Logout</a>
            <?php else: ?>
                <a href="canteens.php" class="active">View Canteens</a>
                <a href="../login.php" class="login-link">Login to Order</a>
            <?php endif; ?>
        </nav>
    </div>

    <div class="main-content">
        <div class="header-card">
            <h1>Menu for <?= htmlspecialchars($canteen['name']); ?></h1>
            <p>Explore top-rated dishes from our verified CCP Campus Partners.</p>
        </div>

        <?php if (isset($_GET['success'])): ?>
            <div class="alert-success">✨ Awesome! Item added to your cart successfully.</div>
        <?php endif; ?>

        <div class="menu-grid">
            <?php if (count($menu_items) > 0): ?>
                <?php foreach ($menu_items as $item): ?>
                <div class="food-card">
                    <div class="image-wrapper">
                        <?php $imagePath = !empty($item['image_url']) ? $item['image_url'] : '../assets/images/default.jpg'; ?>
                        <img src="<?= htmlspecialchars($imagePath); ?>" 
                             alt="<?= htmlspecialchars($item['name']); ?>" 
                             class="food-img"
                             onerror="this.src='../assets/images/default.jpg'">
                    </div>

                    <div class="card-body">
                        <span class="category-badge"><?= htmlspecialchars($item['category']); ?></span>
                        <h3><?= htmlspecialchars($item['name']); ?></h3>
                        <div class="price">₹<?= number_format($item['price'], 2); ?></div>

                        <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'customer'): ?>
                            <form action="cart.php" method="POST" class="add-to-cart-form">
                                <input type="hidden" name="item_id" value="<?= $item['id']; ?>">
                                <input type="hidden" name="canteen_id" value="<?= $canteen_id; ?>">
                                <input type="number" name="quantity" value="1" min="1" max="20" class="qty-input" required>
                                <button type="submit" name="add_to_cart" class="btn-add">Add to Cart</button>
                            </form>
                        <?php else: ?>
                            <div class="add-to-cart-form">
                                <a href="../login.php" class="btn-add" style="width:100%;">Add to Cart</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="grid-column: 1 / -1; text-align: center; padding: 60px; background: white; border-radius: 24px;">
                    <h2 style="color: var(--text-muted);">The kitchen is currently updating.</h2>
                    <p>Check back in a few minutes!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($cart_count > 0 && isset($_SESSION['user_id']) && $_SESSION['role'] === 'customer'): ?>
    <a href="cart.php" class="floating-cart">
        🛒 View Order <span class="cart-badge"><?= $cart_count; ?> items</span>
    </a>
    <?php endif; ?>

</body>
</html>