<?php
session_start();
require_once '../config/db.php';

// Check if customer is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit();
}

// Fetch only active canteens
$stmt = $pdo->query("SELECT * FROM canteens WHERE status = 1 ORDER BY name ASC");
$canteens = $stmt->fetchAll();

// Handle error messages from redirect
$error_msg = '';
if (isset($_GET['error']) && $_GET['error'] === 'offline') {
    $error_msg = "⚠️ This canteen has just gone offline and is not accepting orders.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Canteen | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
            --danger: #ef4444;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            color: var(--text-main);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            color: white;
            padding: 40px 24px;
            position: fixed;
            box-sizing: border-box;
        }

        .logo {
            font-size: 32px;
            font-weight: 800;
            color: white;
            margin-bottom: 40px;
        }

        .logo span {
            color: var(--primary);
        }

        .nav-item {
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
            transition: 0.2s;
        }

        .nav-item:hover,
        .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .main-content {
            margin-left: 280px;
            padding: 40px 60px;
            width: calc(100% - 280px);
            box-sizing: border-box;
        }

        .section-header {
            margin-bottom: 40px;
        }

        .section-header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 800;
        }

        .section-header p {
            margin: 5px 0 0;
            color: var(--text-muted);
            font-weight: 600;
        }

        .alert-error {
            background: #fef2f2;
            color: #991b1b;
            padding: 16px;
            border-radius: 12px;
            margin-bottom: 30px;
            font-weight: 600;
            border: 1px solid #fee2e2;
        }

        .canteen-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
        }

        .canteen-card {
            background: var(--white);
            border-radius: 24px;
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid #f1f5f9;
            transition: 0.3s;
        }

        .canteen-card:hover {
            transform: translateY(-5px);
        }

        .image-container {
            width: 100%;
            height: 200px;
            overflow: hidden;
            background: #f1f5f9;
        }

        .canteen-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .card-body {
            padding: 25px;
        }

        .canteen-name {
            font-size: 20px;
            font-weight: 700;
            margin: 0 0 5px 0;
            color: var(--secondary);
        }

        .canteen-location {
            font-size: 13px;
            color: var(--primary);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 5px;
            margin-bottom: 20px;
        }

        .browse-btn {
            display: block;
            text-align: center;
            background: var(--primary);
            color: white;
            text-decoration: none;
            padding: 12px;
            border-radius: 12px;
            font-weight: 700;
            transition: 0.3s;
        }

        .browse-btn:hover {
            background: #d35400;
            box-shadow: 0 8px 15px rgba(230, 126, 34, 0.2);
        }

        .empty-state {
            grid-column: 1/-1;
            text-align: center;
            padding: 60px;
            background: white;
            border-radius: 24px;
            box-shadow: var(--shadow);
        }

        @media (max-width: 900px) {
            body {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .main-content {
                margin-left: 0;
                width: 100%;
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <nav>
            <a href="dashboard.php" class="nav-item">Dashboard</a>
            <a href="canteens.php" class="nav-item active">Order Food</a>
            <a href="orders.php" class="nav-item">My Orders</a>
            <a href="profile.php" class="nav-item">Profile</a>
            <a href="../logout.php" class="nav-item" style="margin-top: 50px; color: #ef4444;">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="section-header">
            <h1>Select a Canteen</h1>
            <p>Order fresh meals from our verified CCP partners across Charusat University.</p>
        </div>

        <?php if ($error_msg): ?>
            <div class="alert-error"><?= htmlspecialchars($error_msg) ?></div>
        <?php endif; ?>

        <div class="canteen-grid">
            <?php if (count($canteens) > 0): ?>
                <?php foreach ($canteens as $c): ?>
                <div class="canteen-card">
                    <div class="image-container">
                        <?php 
                            // CHECK FOR THE UPLOADED PROFILE IMAGE
                            if (!empty($c['image'])) {
                                $clean_path = '../assets/images/canteens/' . $c['image'];
                            } else {
                                $clean_path = '../assets/images/default.jpg';
                            }
                        ?>
                        <img 
                            src="<?= htmlspecialchars($clean_path); ?>" 
                            alt="<?= htmlspecialchars($c['name']); ?>" 
                            class="canteen-img"
                            onerror="this.src='../assets/images/default.jpg'"
                        >
                    </div>
                    <div class="card-body">
                        <h3 class="canteen-name"><?= htmlspecialchars($c['name']); ?></h3>
                        <div class="canteen-location">📍 <?= htmlspecialchars($c['location']); ?></div>
                        <a href="menu.php?canteen_id=<?= $c['id']; ?>" class="browse-btn">Browse Menu</a>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <h3 style="color: var(--text-muted); margin-bottom: 10px;">No Active Canteens Found</h3>
                    <p style="color: #64748b;">Please check back later during university hours.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>