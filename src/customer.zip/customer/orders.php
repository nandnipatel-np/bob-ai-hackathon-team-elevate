<?php
session_start();
require_once '../config/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch customer orders with optional payment status
$stmt = $pdo->prepare("
    SELECT o.*, c.name AS canteen_name, p.payment_status
    FROM orders o
    JOIN canteens c ON o.canteen_id = c.id
    LEFT JOIN payments p ON o.id = p.order_id
    WHERE o.user_id = ?
    ORDER BY o.order_date DESC
");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            color: var(--text-main);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            color: white;
            padding: 40px 24px;
            position: fixed;
            box-sizing: border-box;
        }

        .logo {
            font-size: 32px;
            font-weight: 800;
            color: white;
            margin-bottom: 40px;
        }

        .logo span {
            color: var(--primary);
        }

        .nav-item {
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 8px;
            display: block;
            font-weight: 600;
            transition: 0.2s;
        }

        .nav-item:hover,
        .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .main-content {
            margin-left: 280px;
            padding: 40px 60px;
            width: calc(100% - 280px);
            box-sizing: border-box;
        }

        .order-container {
            background: var(--white);
            border-radius: 24px;
            box-shadow: var(--shadow);
            border: 1px solid #f1f5f9;
            overflow: hidden;
        }

        .order-row {
            display: grid;
            grid-template-columns: 2.2fr 1fr 1fr 1fr;
            align-items: center;
            padding: 25px 30px;
            border-bottom: 1px solid #f1f5f9;
            transition: 0.2s;
        }

        .order-row:hover {
            background: #fafafa;
        }

        .order-info h4 {
            margin: 0;
            font-size: 15px;
            color: var(--secondary);
            font-weight: 800;
        }

        .order-info p {
            margin: 4px 0 0;
            font-size: 13px;
            color: var(--text-muted);
            font-weight: 600;
            line-height: 1.6;
        }

        .status-badge {
            padding: 6px 14px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            display: inline-block;
            text-align: center;
        }

        .status-completed { background: #f0fdf4; color: #16a34a; }
        .status-pending { background: #fffbeb; color: #f59e0b; }
        .status-preparing { background: #eff6ff; color: #3b82f6; }
        .status-ready { background: #fdf2f8; color: #db2777; }

        .payment-badge {
            display: inline-block;
            margin-top: 8px;
            padding: 5px 10px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 700;
            background: #f1f5f9;
            color: #334155;
        }

        .view-btn {
            text-decoration: none;
            color: var(--secondary);
            font-weight: 700;
            font-size: 13px;
            padding: 10px 18px;
            border: 1.5px solid #e2e8f0;
            border-radius: 12px;
            text-align: center;
            transition: 0.2s;
        }

        .view-btn:hover {
            background: #f8fafc;
            border-color: var(--primary);
            color: var(--primary);
        }

        .price-text {
            font-weight: 800;
            font-size: 18px;
            color: var(--secondary);
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <nav>
            <a href="dashboard.php" class="nav-item">Dashboard</a>
            <a href="canteens.php" class="nav-item">Order Food</a>
            <a href="orders.php" class="nav-item active">My Orders</a>
            <a href="profile.php" class="nav-item">Profile</a>
            <a href="../logout.php" class="nav-item" style="color: #ef4444; margin-top: 40px;">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <h1 style="margin-top: 0; margin-bottom: 10px; font-weight: 800;">Order History</h1>
        <p style="color: var(--text-muted); margin-bottom: 30px; font-weight: 600;">
            Track your orders and view digital receipts from CCP partners.
        </p>

        <div class="order-container">
            <?php if (count($orders) > 0): ?>
                <?php foreach ($orders as $o): ?>
                    <?php
                        $order_date = $o['order_date'] ?? $o['created_at'] ?? null;
                        $pickup_time = $o['scheduled_pickup_time'] ?? null;
                    ?>
                    <div class="order-row">
                        <div class="order-info">
                            <h4>Order #<?= htmlspecialchars($o['order_number']); ?></h4>
                            <p>
                                <?= htmlspecialchars($o['canteen_name']); ?> • 
                                <?= $order_date ? date('d M, Y', strtotime($order_date)) : 'N/A'; ?>
                                <?php if ($pickup_time): ?>
                                    <br>Pickup: <?= date('d M, h:i A', strtotime($pickup_time)); ?>
                                <?php endif; ?>
                            </p>

                            <?php if (!empty($o['payment_status'])): ?>
                                <span class="payment-badge"><?= htmlspecialchars($o['payment_status']); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="price-text">₹<?= number_format($o['total_amount'], 2); ?></div>

                        <div>
                            <span class="status-badge status-<?= strtolower($o['status']); ?>">
                                <?= htmlspecialchars($o['status']); ?>
                            </span>
                        </div>

                        <a href="order_details.php?id=<?= $o['id']; ?>" class="view-btn">View Receipt</a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="padding: 80px; text-align: center; color: var(--text-muted);">
                    <h3 style="margin-bottom: 10px;">No orders found</h3>
                    <p>It looks like you haven't placed any orders yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>