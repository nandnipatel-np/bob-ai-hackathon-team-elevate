<?php
session_start();
require_once '../config/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch User Details
$stmt = $pdo->prepare("SELECT customer_id, name, email, phone FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// If user not found
if (!$user) {
    session_unset();
    session_destroy();
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            color: var(--text-main);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            color: white;
            padding: 40px 24px;
            position: fixed;
            box-sizing: border-box;
        }

        .sidebar .logo {
            font-size: 32px;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 40px;
            display: block;
            text-decoration: none;
        }

        .sidebar .logo span {
            color: var(--primary);
        }

        .nav-item {
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
            transition: 0.2s;
        }

        .nav-item:hover,
        .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .main-content {
            margin-left: 280px;
            padding: 40px 60px;
            width: calc(100% - 280px);
            box-sizing: border-box;
        }

        .profile-container {
            max-width: 800px;
            background: var(--white);
            padding: 40px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            border: 1px solid #f1f5f9;
        }

        .profile-header {
            display: flex;
            align-items: center;
            gap: 25px;
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 1px solid #f1f5f9;
        }

        .avatar-circle {
            width: 80px;
            height: 80px;
            background: var(--primary);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 700;
        }

        .info-group {
            margin-bottom: 25px;
        }

        .info-label {
            font-size: 13px;
            text-transform: uppercase;
            color: var(--text-muted);
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 8px;
        }

        .info-value {
            font-size: 18px;
            font-weight: 600;
            color: var(--secondary);
        }

        .btn-edit {
            background: var(--primary);
            color: white;
            padding: 14px 30px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 700;
            display: inline-block;
            margin-top: 10px;
            transition: 0.3s;
        }

        .btn-edit:hover {
            background: #d35400;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(230, 126, 34, 0.2);
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <a href="dashboard.php" class="logo">CC<span>P</span></a>
        <nav>
            <a href="dashboard.php" class="nav-item">Dashboard</a>
            <a href="canteens.php" class="nav-item">Order Food</a>
            <a href="orders.php" class="nav-item">My Orders</a>
            <a href="profile.php" class="nav-item active">Profile</a>
            <a href="../logout.php" class="nav-item" style="margin-top: 50px; color: #ef4444;">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <h1 style="margin-top: 0; margin-bottom: 30px; font-weight: 800;">Account Settings</h1>

        <div class="profile-container">
            <div class="profile-header">
                <div class="avatar-circle">
                    <?php echo strtoupper(substr($user['name'] ?? 'U', 0, 1)); ?>
                </div>
                <div>
                    <h2 style="margin:0; font-weight: 800;"><?php echo htmlspecialchars($user['name']); ?></h2>
                    <p style="margin:5px 0 0; color: var(--text-muted); font-weight: 600;">Customer at Charusat University</p>
                </div>
            </div>

            <div class="info-group">
                <div class="info-label">Customer ID</div>
                <div class="info-value"><?php echo htmlspecialchars($user['customer_id']); ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Full Name</div>
                <div class="info-value"><?php echo htmlspecialchars($user['name']); ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Email Address</div>
                <div class="info-value"><?php echo htmlspecialchars($user['email']); ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Phone Number</div>
                <div class="info-value"><?php echo !empty($user['phone']) ? htmlspecialchars($user['phone']) : 'Not provided'; ?></div>
            </div>

            <a href="edit_profile.php" class="btn-edit">Edit Profile Information</a>
        </div>
    </div>

</body>
</html>