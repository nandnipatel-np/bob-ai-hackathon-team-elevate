<?php
session_start();
require_once '../config/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit();
}

$query = isset($_GET['query']) ? trim($_GET['query']) : '';
$results = [];

// Redirect if empty search
if ($query === '') {
    header("Location: dashboard.php");
    exit();
}

// Search menu items from active canteens
$stmt = $pdo->prepare("
    SELECT m.*, c.name AS canteen_name 
    FROM menu_items m 
    JOIN canteens c ON m.canteen_id = c.id 
    WHERE (m.name LIKE ? OR m.category LIKE ?)
      AND m.availability > 0 
      AND c.status = 1
    ORDER BY m.name ASC
");
$stmt->execute(['%' . $query . '%', '%' . $query . '%']);
$results = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            margin: 0;
            display: flex;
            color: var(--text-main);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: var(--secondary);
            color: white;
            padding: 40px 24px;
            position: fixed;
            box-sizing: border-box;
        }

        .logo {
            font-size: 32px;
            font-weight: 800;
            color: var(--white);
            margin-bottom: 40px;
        }

        .logo span {
            color: var(--primary);
        }

        .nav-item {
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: 0.3s;
            font-weight: 600;
        }

        .nav-item:hover,
        .nav-item.active {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .main-content {
            margin-left: 280px;
            padding: 40px 60px;
            width: 100%;
            box-sizing: border-box;
        }

        .result-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }

        .food-card {
            background: var(--white);
            border-radius: 24px;
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid #f1f5f9;
            transition: 0.3s;
        }

        .food-card:hover {
            transform: translateY(-10px);
        }

        .food-img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            background: #f8fafc;
        }

        .card-body {
            padding: 20px;
        }

        .canteen-tag {
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--primary);
            margin-bottom: 10px;
            display: block;
        }

        .item-name {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .item-category {
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 14px;
            font-weight: 600;
        }

        .price-btn-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .price {
            font-size: 20px;
            font-weight: 800;
        }

        .order-link {
            background: var(--primary);
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: 0.3s;
        }

        .order-link:hover {
            background: #d35400;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo">CC<span>P</span></div>
        <nav>
            <a href="dashboard.php" class="nav-item">Dashboard</a>
            <a href="canteens.php" class="nav-item">Order Food</a>
            <a href="orders.php" class="nav-item">My Orders</a>
            <a href="profile.php" class="nav-item">Profile</a>
            <a href="../logout.php" class="nav-item" style="color: #ef4444; margin-top: 20px;">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <h1>Search Results for "<?php echo htmlspecialchars($query); ?>"</h1>

        <?php if (count($results) > 0): ?>
            <div class="result-grid">
                <?php foreach ($results as $item): ?>
                    <?php $imagePath = !empty($item['image_url']) ? $item['image_url'] : '../assets/images/default.jpg'; ?>
                    <div class="food-card">
                        <img src="<?php echo htmlspecialchars($imagePath); ?>" 
                             class="food-img" 
                             alt="<?php echo htmlspecialchars($item['name']); ?>"
                             onerror="this.src='../assets/images/default.jpg'">

                        <div class="card-body">
                            <span class="canteen-tag">📍 <?php echo htmlspecialchars($item['canteen_name']); ?></span>
                            <div class="item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                            <div class="item-category"><?php echo htmlspecialchars($item['category']); ?></div>

                            <div class="price-btn-row">
                                <div class="price">₹<?php echo number_format($item['price'], 2); ?></div>
                                <a href="menu.php?canteen_id=<?php echo $item['canteen_id']; ?>" class="order-link">Go to Menu</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div style="margin-top: 50px; text-align: center;">
                <h3 style="color: var(--text-muted);">No items found from active canteens.</h3>
                <p style="color: #64748b;">Try searching by food name or category like <strong>Maggi</strong>, <strong>Beverages</strong>, or <strong>Snacks</strong>.</p>
                <a href="dashboard.php" style="color: var(--primary); font-weight: 700; text-decoration: none;">Back to Dashboard</a>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>