<?php
session_start();
require_once '../config/db.php';

// Security check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php?msg=login_required");
    exit();
}

// Checkout session validation
if (
    empty($_SESSION['cart']) ||
    !isset($_SESSION['checkout_total']) ||
    !isset($_SESSION['checkout_canteen_id']) ||
    !isset($_SESSION['checkout_pickup_time']) ||
    !isset($_SESSION['pending_order_number'])
) {
    header("Location: cart.php");
    exit();
}

date_default_timezone_set('Asia/Kolkata');

$total_amount = (float) $_SESSION['checkout_total'];
$canteen_id = (int) $_SESSION['checkout_canteen_id'];
$pickup_time = $_SESSION['checkout_pickup_time'];
$order_number = $_SESSION['pending_order_number'];

// --- TIMER LOGIC (10 Minutes) ---
$payment_timeout = 600; 

if (!isset($_SESSION['payment_start_time'])) {
    $_SESSION['payment_start_time'] = time();
}

$time_elapsed = time() - $_SESSION['payment_start_time'];
$time_remaining = $payment_timeout - $time_elapsed;

function clearCheckoutSession() {
    unset(
        $_SESSION['cart'],
        $_SESSION['checkout_canteen_id'],
        $_SESSION['checkout_total'],
        $_SESSION['checkout_pickup_time'],
        $_SESSION['pending_order_number'],
        $_SESSION['payment_start_time']
    );
}

if ($time_remaining <= 0 && !isset($_POST['confirm_payment'])) {
    clearCheckoutSession();
    header("Location: cart.php?error=timeout");
    exit();
}

$error = '';

if (isset($_POST['confirm_payment'])) {
    if ($time_remaining <= 0) {
        $error = "Payment time expired. Please start again.";
        clearCheckoutSession();
    } elseif (!isset($_FILES['payment_proof']) || $_FILES['payment_proof']['error'] !== 0) {
        $error = "Payment screenshot is strictly required.";
    } else {

        // Absolute server folder
        $target_dir = dirname(__DIR__) . "/assets/images/proofs/";

        // Relative DB/browser path
        $db_folder = "assets/images/proofs/";

        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $file_ext = strtolower(pathinfo($_FILES["payment_proof"]["name"], PATHINFO_EXTENSION));
        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($file_ext, $allowed_exts)) {
            $error = "Invalid file type. Please upload a JPG, PNG, or WEBP image.";
        } else {
            $proof_filename = "proof_" . time() . "_" . rand(1000, 9999) . "." . $file_ext;

            // Full server file path
            $proof_full_path = $target_dir . $proof_filename;

            // What we store in DB
            $proof_db_path = $db_folder . $proof_filename;

        if (move_uploaded_file($_FILES["payment_proof"]["tmp_name"], $proof_full_path)) {
            try {
                 $pdo->beginTransaction();

            // 1. Insert Order
            $stmt = $pdo->prepare("
            INSERT INTO orders 
            (user_id, canteen_id, order_number, total_amount, scheduled_pickup_time, status) 
            VALUES (?, ?, ?, ?, ?, 'Pending')
            ");
            $stmt->execute([$_SESSION['user_id'], $canteen_id, $order_number, $total_amount, $pickup_time]);

            $order_id = $pdo->lastInsertId();

            // 2. Insert Order Items
            foreach ($_SESSION['cart'] as $id => $qty) {
            $stmt = $pdo->prepare("SELECT price FROM menu_items WHERE id = ?");
            $stmt->execute([$id]);
            $price = $stmt->fetchColumn();

            if ($price === false) {
                throw new Exception("Item ID $id not found.");
            }

            $subtotal = $price * $qty;

            $stmt = $pdo->prepare("
                INSERT INTO order_details (order_id, item_id, quantity, subtotal) 
                VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([$order_id, $id, $qty, $subtotal]);
            }

            // 3. Insert Payment Record
            $stmt = $pdo->prepare("
            INSERT INTO payments 
            (order_id, user_id, payment_method, payment_status, transaction_proof, payment_date) 
            VALUES (?, ?, 'QR', 'Paid', ?, NOW())
            ");
            $stmt->execute([$order_id, $_SESSION['user_id'], $proof_db_path]);

            $pdo->commit();
            clearCheckoutSession();

            header("Location: orders.php?success=1");
            exit();

            } catch (Exception $e) {
            $pdo->rollBack();
            $error = "System Error: " . $e->getMessage();
            }
        } else {
                $error = "Image upload failed. Check folder permissions.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
            --success: #10b981;
        }

        body {
            margin: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg);
            display: flex;
        }

        .sidebar {
            width: 280px;
            background: var(--secondary);
            color: white;
            height: 100vh;
            padding: 40px 24px;
            position: fixed;
            box-sizing: border-box;
        }

        .sidebar h2 {
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 40px;
            color: white;
        }

        .sidebar h2 span {
            color: var(--primary);
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #94a3b8;
            text-decoration: none;
            padding: 14px 16px;
            margin-bottom: 8px;
            border-radius: 12px;
            font-weight: 600;
            transition: 0.2s;
        }

        .sidebar a:hover {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .main-content {
            margin-left: 280px;
            padding: 40px 60px;
            width: 100%;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .payment-card {
            background: var(--white);
            padding: 45px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            text-align: center;
            width: 100%;
            max-width: 480px;
            border: 1px solid #f1f5f9;
        }

        .order-badge {
            background: #fff7ed;
            color: var(--primary);
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 800;
            display: inline-block;
            margin-bottom: 25px;
        }

        h1 {
            font-size: 28px;
            font-weight: 800;
            color: var(--secondary);
            margin: 0 0 10px 0;
        }

        .amount-display {
            font-size: 48px;
            color: var(--success);
            font-weight: 800;
            margin: 20px 0;
        }

        .qr-section {
            background: #fdfdfd;
            border: 2px dashed #e2e8f0;
            border-radius: 20px;
            padding: 30px;
            margin: 30px 0;
        }

        .qr-section img {
            width: 240px;
            height: auto;
        }

        .form-group {
            text-align: left;
            margin-bottom: 30px;
        }

        .form-group label {
            display: block;
            font-size: 12px;
            font-weight: 700;
            color: var(--text-muted);
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        input[type="file"] {
            width: 100%;
            font-family: inherit;
            font-size: 14px;
            padding: 12px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            box-sizing: border-box;
            background: #f8fafc;
        }

        .btn-confirm {
            background: var(--success);
            color: white;
            border: none;
            padding: 18px;
            border-radius: 14px;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
            width: 100%;
            transition: 0.3s;
        }

        .btn-confirm:hover {
            background: #059669;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(16, 185, 129, 0.2);
        }

        .btn-cancel {
            display: block;
            margin-top: 20px;
            color: #ef4444;
            text-decoration: none;
            font-weight: 700;
            font-size: 14px;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-weight: 600;
            font-size: 14px;
            border: 1px solid #fecaca;
        }

        .timer-box {
            background: #eff6ff;
            color: #2563eb;
            padding: 10px 20px;
            border-radius: 12px;
            font-weight: 800;
            font-size: 16px;
            margin-bottom: 20px;
            display: inline-block;
            border: 1px solid #bfdbfe;
        }

        #timeout-msg {
            background: #fef2f2;
            color: #dc2626;
            padding: 20px;
            border-radius: 16px;
            font-weight: 700;
            font-size: 16px;
            margin: 20px 0;
            border: 1px solid #fecaca;
            display: none;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>CC<span>P</span></h2>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="canteens.php">Order Food</a>
            <a href="orders.php">My Orders</a>
            <a href="profile.php">Profile</a>
            <a href="../logout.php" style="color:#ef4444; margin-top: 50px;">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="payment-card">
            <span class="order-badge">Order #<?= htmlspecialchars($order_number); ?></span>
            <h1>Scan & Pay</h1>
            <p style="color: var(--text-muted); font-weight: 500;">Complete your transfer via any UPI app</p>

            <div class="amount-display">₹<?= number_format($total_amount, 2); ?></div>

            <?php if ($error): ?>
                <div class="alert-error">⚠️ <?= htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <div class="timer-box" id="timer-container">
                Expires in: <span id="timer">--:--</span>
            </div>

            <div id="timeout-msg">
                ⏱️ Payment session expired. Please restart your order.
            </div>

            <div class="qr-section" id="qr-section">
                <img src="../assets/images/qr.jpeg" alt="Payment QR Code">
            </div>

            <form method="POST" enctype="multipart/form-data" id="payment-form">
                <div class="form-group">
                    <label>Upload Payment Proof (Screenshot)</label>
                    <input type="file" name="payment_proof" accept="image/*" required>
                </div>

                <button type="submit" name="confirm_payment" class="btn-confirm">Confirm Order</button>
            </form>

            <a href="cart.php" class="btn-cancel">Cancel Order</a>
        </div>

        <p style="font-size: 12px; color: var(--text-muted); margin-top: 30px; font-weight: 600; text-align: center;">
            Secure Payment processing for <strong>CCP Campus Dining</strong>
        </p>
    </div>

    <script>
    let timeRemaining = <?= max(0, $time_remaining); ?>;
    const timerDisplay = document.getElementById('timer');
    const timerContainer = document.getElementById('timer-container');
    const paymentForm = document.getElementById('payment-form');
    const qrSection = document.getElementById('qr-section');
    const timeoutMsg = document.getElementById('timeout-msg');

    if (timeRemaining > 0) {
        const countdown = setInterval(() => {
            timeRemaining--;
            if (timeRemaining <= 0) {
                clearInterval(countdown);
                handleTimeout();
            } else {
                updateTimerDisplay();
            }
        }, 1000);
        updateTimerDisplay();
    } else {
        handleTimeout();
    }

    function updateTimerDisplay() {
        const minutes = Math.floor(timeRemaining / 60);
        const seconds = timeRemaining % 60;
        timerDisplay.innerHTML = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    function handleTimeout() {
        timerContainer.style.display = 'none';
        qrSection.style.display = 'none';
        paymentForm.style.display = 'none';
        timeoutMsg.style.display = 'block';
        setTimeout(() => { window.location.href = 'cart.php?error=timeout'; }, 3000);
    }
    </script>
</body>
</html>