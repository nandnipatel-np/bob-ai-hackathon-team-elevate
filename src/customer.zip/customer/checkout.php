<?php
session_start();
require_once '../config/db.php';

// Only logged-in customers can access checkout
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php?msg=login_required");
    exit();
}

// Cart must not be empty
if (empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit();
}

// Set timezone
date_default_timezone_set('Asia/Kolkata');

// Calculate total safely and verify items exist
$total = 0;
foreach ($_SESSION['cart'] as $id => $qty) {
    $stmt = $pdo->prepare("SELECT price FROM menu_items WHERE id = ?");
    $stmt->execute([$id]);
    $item = $stmt->fetch();

    if ($item) {
        $total += ($item['price'] * $qty);
    }
}

// FIX: Ensure canteen_id is captured. 
// If it's not in checkout_canteen_id, try to get it from the general session.
$canteen_id = $_SESSION['checkout_canteen_id'] ?? $_SESSION['selected_canteen_id'] ?? null;

if (!$canteen_id) {
    // If we still don't have a canteen ID, we can't process the order.
    header("Location: cart.php?error=missing_canteen");
    exit();
}

// Minimum pickup time = 20 mins from now
$min_datetime = date('Y-m-d\TH:i', strtotime('+20 minutes'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw_pickup_time = $_POST['pickup_time'];
    $pickup_timestamp = strtotime($raw_pickup_time);
    $minimum_allowed = strtotime('+15 minutes'); // Slight buffer for server lag

    if (!$pickup_timestamp || $pickup_timestamp < $minimum_allowed) {
        $error_msg = "Pickup time must be at least 20 minutes from now.";
    } else {
        // SUCCESS: Store all necessary data into the session for payment.php
        $_SESSION['checkout_total'] = $total;
        $_SESSION['checkout_canteen_id'] = $canteen_id;
        $_SESSION['checkout_pickup_time'] = date('Y-m-d H:i:s', $pickup_timestamp);
        
        // Generate a fresh unique order reference
        $_SESSION['pending_order_number'] = 'MG' . strtoupper(substr(uniqid(), 8)) . mt_rand(10, 99);

        // Redirect to payment
        header("Location: payment.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | Mesh Grab</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #e67e22;
            --secondary: #1a1a1a;
            --bg: #f8fafc;
            --white: #ffffff;
            --text-main: #2d3436;
            --text-muted: #636e72;
            --shadow: 0 10px 30px rgba(0,0,0,0.04);
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: var(--text-main);
        }

        .checkout-card {
            background: var(--white);
            padding: 40px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 420px;
            border: 1px solid #f1f5f9;
        }

        h2 {
            margin: 0 0 10px 0;
            font-size: 28px;
            font-weight: 800;
            color: var(--secondary);
        }

        .subtitle {
            color: var(--text-muted);
            font-size: 14px;
            margin-bottom: 30px;
            font-weight: 500;
        }

        .total-box {
            background: #fff7ed;
            padding: 20px;
            border-radius: 16px;
            margin-bottom: 25px;
            text-align: center;
        }

        .total-label {
            font-size: 13px;
            font-weight: 700;
            color: var(--primary);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .total-pay {
            font-size: 32px;
            font-weight: 800;
            color: var(--secondary);
            margin-top: 5px;
        }

        label {
            display: block;
            font-size: 14px;
            font-weight: 700;
            color: var(--secondary);
            margin-bottom: 8px;
        }

        input[type="datetime-local"] {
            width: 100%;
            padding: 14px;
            margin-bottom: 25px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            font-family: inherit;
            font-size: 16px;
            box-sizing: border-box;
            background: #fbfcfd;
            outline: none;
        }

        input[type="datetime-local"]:focus {
            border-color: var(--primary);
        }

        .btn-pay {
            width: 100%;
            padding: 16px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-pay:hover {
            background: #d35400;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(230, 126, 34, 0.2);
        }

        .cancel-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: var(--text-muted);
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
        }

        .alert-error {
            background: #fef2f2;
            color: #991b1b;
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 600;
            border: 1px solid #fee2e2;
        }
    </style>
</head>
<body>
    <div class="checkout-card">
        <h2>Checkout</h2>
        <p class="subtitle">Complete your details to place the order.</p>

        <?php if (!empty($error_msg)): ?>
            <div class="alert-error"><?= htmlspecialchars($error_msg) ?></div>
        <?php endif; ?>

        <div class="total-box">
            <div class="total-label">Total Amount</div>
            <div class="total-pay">₹<?= number_format($total, 2); ?></div>
        </div>

        <form method="POST">
            <label for="pickup_time">Preferred Pickup Date & Time</label>
            <input type="datetime-local" id="pickup_time" name="pickup_time" min="<?= $min_datetime ?>" value="<?= $min_datetime ?>" required>

            <button type="submit" class="btn-pay">Proceed to Payment</button>
        </form>

        <a href="cart.php" class="cancel-link">Return to Cart</a>
    </div>
</body>
</html>