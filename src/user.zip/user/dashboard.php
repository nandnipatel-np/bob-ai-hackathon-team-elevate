<?php
session_start();
include("../includes/session.php");

// Restrict only customers
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard | CCP</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background: #f7f9fc; 
            margin: 0; 
            display: flex; 
            flex-direction: column; 
            min-height: 100vh;
        }

        .header {
            background-color: white;
            padding: 15px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.02);
        }

        .header-logo {
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .header-logo .cc-part {
            font-size: 32px;
            font-weight: 800;
            color: #1e293b;
        }

        .header-logo .p-part {
            font-size: 32px;
            font-weight: 800;
            color: #e67e22;
        }

        .header-nav a {
            text-decoration: none;
            color: #4b5563;
            font-weight: 600;
            font-size: 15px;
            margin-left: 20px;
        }

        .main-content {
            flex-grow: 1;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
        }

        .dashboard-card { 
            background: white; 
            padding: 40px; 
            border-radius: 20px; 
            box-shadow: 0 10px 40px rgba(0,0,0,0.03); 
            width: 100%; 
            max-width: 800px; 
        }

        h2 { margin: 0 0 10px 0; color: #1e293b; font-size: 28px; }

        .welcome-text { 
            color: #64748b; 
            font-size: 18px; 
            margin-bottom: 30px; 
        }
        
        .logout-btn {
            display: inline-block;
            background: #e67e22;
            color: white;
            padding: 10px 20px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            transition: 0.2s;
        }

        .logout-btn:hover { 
            background: #d35400; 
        }
    </style>
</head>
<body>

    <header class="header">
        <a href="dashboard.php" class="header-logo">
            <span class="cc-part">CC</span><span class="p-part">P</span>
        </a>

        <nav class="header-nav">
            <a href="profile.php">My Profile</a>
            <a href="../logout.php" style="color: #e11d48;">Logout</a>
        </nav>
    </header>

    <main class="main-content">
        <div class="dashboard-card">
            <h2>User Dashboard</h2>

            <p class="welcome-text">
                Welcome back, 
                <strong><?php echo htmlspecialchars($_SESSION['name']); ?></strong>!
            </p>
            
            <hr style="border: 0; border-top: 1px solid #f1f5f9; margin: 20px 0;">
            
            <div class="content-area">
                <p>Manage your canteen orders and account settings from here.</p>
            </div>

            <div style="margin-top: 30px;">
                <a href="../logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </main>

</body>
</html>